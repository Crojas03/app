import { useState } from 'react';
import { ClipboardList, CalendarDays, CreditCard, RefreshCw, Database, AlertCircle, Receipt, ChartPie, Truck } from 'lucide-react';
import { useAppData } from '@/hooks/useAppData';
import { RegistroView } from '@/components/registro/RegistroView';
import { CierresView } from '@/components/cierres/CierresView';
import { MetodosView } from '@/components/metodos/MetodosView';
import { GastosView } from '@/components/gastos/GastosView';
import { ResumenView } from '@/components/resumen/ResumenView';
import { SuppliersView } from '@/components/proveedores/SuppliersView';
import { Skeleton } from '@/components/ui/Skeleton';
import { seedDemoData } from '@/lib/seedData';
import type { Sale } from '@/lib/supabase';

type View = 'registro' | 'gastos' | 'cierres' | 'resumen' | 'proveedores' | 'metodos';

export default function App() {
  const data = useAppData();
  const [view, setView] = useState<View>('registro');
  const [seeding, setSeeding] = useState(false);
  const [seedMsg, setSeedMsg] = useState<string | null>(null);

  async function handleSeed() {
    setSeeding(true);
    setSeedMsg(null);
    try {
      const r = await seedDemoData(data.methods, data.expenseCategories, data.expenseSubcategories);
      setSeedMsg(`Datos de prueba creados: ${r.sales} ventas, ${r.cashBacks} vueltos, ${r.tips} propinas y ${r.expenses} gastos en los últimos 30 días.`);
      await data.refresh();
    } catch (e) {
      setSeedMsg(e instanceof Error ? e.message : 'No se pudieron crear los datos de prueba.');
    } finally {
      setSeeding(false);
    }
  }

  const navItems: { id: View; label: string; icon: typeof ClipboardList }[] = [
    { id: 'registro', label: 'Registro', icon: ClipboardList },
    { id: 'gastos', label: 'Gastos', icon: Receipt },
    { id: 'cierres', label: 'Cierres', icon: CalendarDays },
    { id: 'resumen', label: 'Resumen General', icon: ChartPie },
    { id: 'proveedores', label: 'Proveedores', icon: Truck },
    { id: 'metodos', label: 'Métodos', icon: CreditCard },
  ];

  if (data.loading) {
    return (
      <div className="min-h-screen bg-slate-100">
        <header className="bg-white border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
            <Skeleton className="h-10 w-10 rounded-xl" />
            <Skeleton className="h-6 w-56" />
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 py-6 space-y-4">
          <Skeleton className="h-12 w-full max-w-md" />
          <Skeleton className="h-64 w-full" />
        </main>
      </div>
    );
  }

  const hasNoData = data.sales.length === 0 && data.expenses.length === 0;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2.5 mr-auto">
            <div className="w-10 h-10 rounded-xl bg-sky-600 flex items-center justify-center text-white">
              <ClipboardList size={20} />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Control de Turnos</h1>
              <p className="text-xs text-slate-400">Ventas, gastos, vueltos y propinas</p>
            </div>
          </div>
          <nav className="flex gap-1 rounded-xl bg-slate-100 p-1 order-3 sm:order-2 w-full sm:w-auto overflow-x-auto">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setView(id)}
                className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition whitespace-nowrap ${
                  view === id ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-1 order-2 sm:order-3">
            {hasNoData && !seeding && (
              <button
                onClick={handleSeed}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs sm:text-sm font-semibold text-white hover:bg-emerald-700 transition"
                title="Cargar datos de prueba"
              >
                <Database size={15} />
                <span className="hidden sm:inline">Datos de prueba</span>
              </button>
            )}
            <button
              onClick={() => data.refresh()}
              className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
              title="Actualizar"
            >
              <RefreshCw size={18} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 pb-16">
        {data.error && (
          <div className="mb-5 flex items-start gap-2.5 rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-sm text-rose-700">
            <AlertCircle size={18} className="shrink-0 mt-0.5" />
            <div>
              <p className="font-medium">No se pudieron cargar los datos.</p>
              <p className="text-rose-600 text-xs mt-0.5">{data.error}</p>
            </div>
          </div>
        )}

        {seedMsg && (
          <div className="mb-5 flex items-start gap-2.5 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-700">
            <Database size={18} className="shrink-0 mt-0.5" />
            <p>{seedMsg}</p>
          </div>
        )}

        {view === 'registro' && (
          <RegistroView
            methods={data.methods}
            sales={data.sales}
            cashBacks={data.cashBacks}
            tips={data.tips}
            onAddSales={data.addSales}
            onDeleteSale={data.deleteSale}
            onUpdateSale={async (id: string, patch: Partial<Sale>) => data.updateSale(id, patch)}
            onAddCashBack={data.addCashBack}
            onDeleteCashBack={data.deleteCashBack}
            onAddTip={data.addTip}
            onDeleteTip={data.deleteTip}
          />
        )}

        {view === 'gastos' && (
          <GastosView
            expenses={data.expenses}
            methods={data.methods}
            categories={data.expenseCategories}
            subcategories={data.expenseSubcategories}
            onAddExpenses={data.addExpenses}
            onDeleteExpense={data.deleteExpense}
            onSaveCategory={data.saveCategory}
            onDeleteCategory={data.deleteCategory}
            onSaveSubcategory={data.saveSubcategory}
            onDeleteSubcategory={data.deleteSubcategory}
          />
        )}

        {view === 'cierres' && (
          <CierresView
            sales={data.sales}
            cashBacks={data.cashBacks}
            tips={data.tips}
            expenses={data.expenses}
            methods={data.methods}
            onDeleteSale={data.deleteSale}
            onUpdateSale={async (id: string, patch: Partial<Sale>) => data.updateSale(id, patch)}
          />
        )}

        {view === 'resumen' && (
          <ResumenView
            sales={data.sales}
            expenses={data.expenses}
            categories={data.expenseCategories}
            subcategories={data.expenseSubcategories}
            movements={data.bankMovements}
            openingBalances={data.openingBalances}
            onSaveOpeningBalance={data.saveOpeningBalance}
            onAddMovements={data.addBankMovements}
            onDeleteMovement={data.deleteBankMovement}
          />
        )}

        {view === 'proveedores' && (
          <SuppliersView
            suppliers={data.suppliers}
            categories={data.expenseCategories}
            onSave={data.saveSupplier}
            onDelete={data.deleteSupplier}
          />
        )}

        {view === 'metodos' && (
          <MetodosView
            methods={data.methods}
            onSave={data.saveMethod}
            onToggle={data.toggleMethod}
            onDelete={data.deleteMethod}
          />
        )}
      </main>
    </div>
  );
}
