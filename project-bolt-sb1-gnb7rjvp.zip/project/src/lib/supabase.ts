import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface PaymentMethod {
  id: string;
  name: string;
  currency: 'VES' | 'USD';
  active: boolean;
  reconciliation_columns: string[];
  sort_order: number;
}

export interface Sale {
  id: string;
  sale_date: string;
  shift: 'diurno' | 'nocturno';
  bcv_rate: number;
  method_id: string;
  amount: number;
  method_currency: 'VES' | 'USD';
  amount_usd: number;
  amount_ves: number;
  notes: string | null;
}

export interface CashBack {
  id: string;
  entry_date: string;
  shift: 'diurno' | 'nocturno';
  concept: string;
  amount: number;
  currency: 'VES' | 'USD';
  delivery_method: 'pago_movil' | 'efectivo_bs';
  bank_account: string | null;
  bcv_rate: number | null;
  notes: string | null;
}

export interface Tip {
  id: string;
  entry_date: string;
  shift: 'diurno' | 'nocturno';
  person: string;
  amount: number;
  currency: 'VES' | 'USD';
  via: string;
  bank_account: string | null;
  bcv_rate: number | null;
  notes: string | null;
}

export interface ExpenseCategory {
  id: string;
  name: string;
  kind: 'operativo' | 'liquidaciones';
  sort_order: number;
}

export interface ExpenseSubcategory {
  id: string;
  category_id: string;
  name: string;
  sort_order: number;
}

export interface Expense {
  id: string;
  expense_date: string;
  bcv_rate: number;
  egress_type: 'operativo' | 'vueltos_propinas';
  category_id: string | null;
  subcategory_id: string | null;
  provider: string;
  method_id: string;
  amount: number;
  method_currency: 'VES' | 'USD';
  amount_usd: number;
  amount_ves: number;
  notes: string | null;
}

export interface Supplier {
  id: string;
  name: string;
  tax_id: string | null;
  default_category_id: string | null;
  phone: string | null;
  notes: string | null;
}

export interface OpeningBalance {
  period_month: string;
  petty_cash_usd: number;
  petty_cash_ves: number;
  capital_usd: number;
  ref_rate: number;
}

export interface BankMovement {
  id: string;
  movement_date: string;
  account: string;
  kind: 'venta_recibida' | 'comision' | 'compra_divisas' | 'adelanto_socios' | 'temporal';
  description: string | null;
  amount: number;
  currency: 'VES' | 'USD';
  bcv_rate: number;
  amount_usd: number;
  amount_ves: number;
}

export const MOVEMENT_KINDS: { id: BankMovement['kind']; label: string }[] = [
  { id: 'venta_recibida', label: 'Venta recibida' },
  { id: 'comision', label: 'Comisión' },
  { id: 'compra_divisas', label: 'Compra de divisas' },
  { id: 'adelanto_socios', label: 'Adelanto a socios' },
  { id: 'temporal', label: 'Movimiento temporal (vueltos/propinas)' },
];
