import { supabase } from '@/lib/supabase';
import { addDays, toISODate } from '@/lib/format';
import type { PaymentMethod, ExpenseCategory, ExpenseSubcategory } from '@/lib/supabase';

const BANKS = ['Banco de Venezuela', 'Banesco', 'Mercantil', 'BNC', 'Banclander'];
const PEOPLE = ['Ana', 'Carlos', 'María', 'Luis', 'Pedro'];
const TIPS_VIAS = ['Pago Móvil Banesco', 'Efectivo Dólares', 'Pago Móvil Mercantil', 'Binance'];
const PROVIDERS = ['Carnicería La Plaza', 'Mercado Municipal', 'Ferretería Central', 'Movistar', 'Corpoelec', 'Distribuidora RV'];

function rnd(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export async function seedDemoData(
  methods: PaymentMethod[],
  categories: ExpenseCategory[],
  subcategories: ExpenseSubcategory[],
): Promise<{ sales: number; cashBacks: number; tips: number; expenses: number }> {
  const active = methods.filter((m) => m.active);
  if (active.length === 0) throw new Error('No hay métodos de pago activos');

  let salesCount = 0;
  let cashBacksCount = 0;
  let tipsCount = 0;
  let expensesCount = 0;

  const opCats = categories.filter((c) => c.kind === 'operativo');
  const liqCat = categories.find((c) => c.kind === 'liquidaciones');

  for (let i = 30; i >= 0; i--) {
    const date = toISODate(addDays(new Date(), -i));
    const rate = round2(rnd(36, 42));

    for (const shift of ['diurno', 'nocturno'] as const) {
      const nSales = Math.floor(rnd(2, 6));
      for (let j = 0; j < nSales; j++) {
        const method = active[Math.floor(Math.random() * active.length)];
        const amount = round2(rnd(10, 120));
        const amountUsd = method.currency === 'USD' ? amount : round2(amount / rate);
        const amountVes = method.currency === 'VES' ? amount : round2(amount * rate);
        const { error } = await supabase.from('sales').insert({
          sale_date: date,
          shift,
          bcv_rate: rate,
          method_id: method.id,
          amount,
          method_currency: method.currency,
          amount_usd: amountUsd,
          amount_ves: amountVes,
        });
        if (error) throw error;
        salesCount++;
      }

      if (Math.random() < 0.4) {
        const isCash = Math.random() < 0.5;
        const currency = isCash ? 'VES' : 'USD';
        const amount = round2(rnd(2, 25));
        const { error } = await supabase.from('cash_backs').insert({
          entry_date: date,
          shift,
          concept: 'Vuelto',
          amount,
          currency,
          delivery_method: isCash ? 'efectivo_bs' : 'pago_movil',
          bank_account: isCash ? null : BANKS[Math.floor(Math.random() * BANKS.length)],
          bcv_rate: rate,
        });
        if (error) throw error;
        cashBacksCount++;
      }

      if (Math.random() < 0.5) {
        const { error } = await supabase.from('tips').insert({
          entry_date: date,
          shift,
          person: PEOPLE[Math.floor(Math.random() * PEOPLE.length)],
          amount: round2(rnd(1, 15)),
          currency: Math.random() < 0.6 ? 'USD' : 'VES',
          via: TIPS_VIAS[Math.floor(Math.random() * TIPS_VIAS.length)],
          bcv_rate: rate,
        });
        if (error) throw error;
        tipsCount++;
      }
    }

    if (opCats.length > 0 && Math.random() < 0.5) {
      const cat = opCats[Math.floor(Math.random() * opCats.length)];
      const subs = subcategories.filter((s) => s.category_id === cat.id);
      const method = active[Math.floor(Math.random() * active.length)];
      const amount = round2(rnd(10, 200));
      const { error } = await supabase.from('expenses').insert({
        expense_date: date,
        bcv_rate: rate,
        egress_type: 'operativo',
        category_id: cat.id,
        subcategory_id: subs.length ? subs[Math.floor(Math.random() * subs.length)].id : null,
        provider: PROVIDERS[Math.floor(Math.random() * PROVIDERS.length)],
        method_id: method.id,
        amount,
        method_currency: method.currency,
        amount_usd: method.currency === 'USD' ? amount : round2(amount / rate),
        amount_ves: method.currency === 'VES' ? amount : round2(amount * rate),
      });
      if (error) throw error;
      expensesCount++;
    }

    if (liqCat && Math.random() < 0.3) {
      const subs = subcategories.filter((s) => s.category_id === liqCat.id);
      const method = active[Math.floor(Math.random() * active.length)];
      const amount = round2(rnd(3, 40));
      const { error } = await supabase.from('expenses').insert({
        expense_date: date,
        bcv_rate: rate,
        egress_type: 'vueltos_propinas',
        category_id: liqCat.id,
        subcategory_id: subs.length ? subs[Math.floor(Math.random() * subs.length)].id : null,
        provider: PEOPLE[Math.floor(Math.random() * PEOPLE.length)],
        method_id: method.id,
        amount,
        method_currency: method.currency,
        amount_usd: method.currency === 'USD' ? amount : round2(amount / rate),
        amount_ves: method.currency === 'VES' ? amount : round2(amount * rate),
      });
      if (error) throw error;
      expensesCount++;
    }
  }

  return { sales: salesCount, cashBacks: cashBacksCount, tips: tipsCount, expenses: expensesCount };
}
