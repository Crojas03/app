import { useCallback, useEffect, useState } from 'react';
import { supabase, type PaymentMethod, type Sale, type CashBack, type Tip, type Expense, type ExpenseCategory, type ExpenseSubcategory, type Supplier, type OpeningBalance, type BankMovement } from '@/lib/supabase';

export interface AppData {
  methods: PaymentMethod[];
  sales: Sale[];
  cashBacks: CashBack[];
  tips: Tip[];
  expenses: Expense[];
  expenseCategories: ExpenseCategory[];
  expenseSubcategories: ExpenseSubcategory[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  addSales: (values: Omit<Sale, 'id' | 'notes'>[]) => Promise<void>;
  updateSale: (id: string, s: Partial<Sale>) => Promise<void>;
  deleteSale: (id: string) => Promise<void>;
  addCashBack: (c: Omit<CashBack, 'id' | 'notes' | 'concept'>) => Promise<void>;
  deleteCashBack: (id: string) => Promise<void>;
  addTip: (t: Omit<Tip, 'id' | 'notes'>) => Promise<void>;
  deleteTip: (id: string) => Promise<void>;
  saveMethod: (m: Omit<PaymentMethod, 'id' | 'sort_order'> & { id?: string }) => Promise<void>;
  toggleMethod: (id: string, active: boolean) => Promise<void>;
  deleteMethod: (id: string) => Promise<void>;
  addExpenses: (values: (Omit<Expense, 'id' | 'notes'> & { notes?: string | null })[]) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;
  saveCategory: (c: { id?: string; name: string; kind: 'operativo' | 'liquidaciones' }) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  saveSubcategory: (s: { id?: string; category_id: string; name: string }) => Promise<void>;
  deleteSubcategory: (id: string) => Promise<void>;
  saveSupplier: (s: { id?: string; name: string; tax_id: string | null; default_category_id: string | null; phone: string | null; notes: string | null }) => Promise<void>;
  deleteSupplier: (id: string) => Promise<void>;
  saveOpeningBalance: (o: Omit<OpeningBalance, 'updated_at'>) => Promise<void>;
  addBankMovements: (values: Omit<BankMovement, 'id'>[]) => Promise<void>;
  deleteBankMovement: (id: string) => Promise<void>;
}

export function useAppData(): AppData {
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [cashBacks, setCashBacks] = useState<CashBack[]>([]);
  const [tips, setTips] = useState<Tip[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>([]);
  const [expenseSubcategories, setExpenseSubcategories] = useState<ExpenseSubcategory[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [openingBalances, setOpeningBalances] = useState<OpeningBalance[]>([]);
  const [bankMovements, setBankMovements] = useState<BankMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const [m, s, c, t, ex, ec, es, sup, ob, bm] = await Promise.all([
        supabase.from('payment_methods').select('*').order('sort_order'),
        supabase.from('sales').select('*').order('sale_date', { ascending: false }).order('created_at', { ascending: false }),
        supabase.from('cash_backs').select('*').order('entry_date', { ascending: false }).order('created_at', { ascending: false }),
        supabase.from('tips').select('*').order('entry_date', { ascending: false }).order('created_at', { ascending: false }),
        supabase.from('expenses').select('*').order('expense_date', { ascending: false }).order('created_at', { ascending: false }),
        supabase.from('expense_categories').select('*').order('sort_order'),
        supabase.from('expense_subcategories').select('*').order('sort_order'),
        supabase.from('suppliers').select('*').order('name'),
        supabase.from('opening_balances').select('*'),
        supabase.from('bank_movements').select('*').order('movement_date', { ascending: false }).order('created_at', { ascending: false }),
      ]);
      if (m.error) throw m.error;
      if (s.error) throw s.error;
      if (c.error) throw c.error;
      if (t.error) throw t.error;
      if (ex.error) throw ex.error;
      if (ec.error) throw ec.error;
      if (es.error) throw es.error;
      if (sup.error) throw sup.error;
      if (ob.error) throw ob.error;
      if (bm.error) throw bm.error;
      setMethods(m.data ?? []);
      setSales(s.data ?? []);
      setCashBacks(c.data ?? []);
      setTips(t.data ?? []);
      setExpenses(ex.data ?? []);
      setExpenseCategories(ec.data ?? []);
      setExpenseSubcategories(es.data ?? []);
      setSuppliers(sup.data ?? []);
      setOpeningBalances(ob.data ?? []);
      setBankMovements(bm.data ?? []);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error al cargar los datos');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const addSales: AppData['addSales'] = async (values) => {
    const { error: err } = await supabase.from('sales').insert(values);
    if (err) throw err;
    await refresh();
  };

  const updateSale: AppData['updateSale'] = async (id, s) => {
    const { error: err } = await supabase.from('sales').update(s).eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const deleteSale: AppData['deleteSale'] = async (id) => {
    const { error: err } = await supabase.from('sales').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const addCashBack: AppData['addCashBack'] = async (c) => {
    const { error: err } = await supabase.from('cash_backs').insert({ ...c, concept: 'Vuelto' });
    if (err) throw err;
    await refresh();
  };

  const deleteCashBack: AppData['deleteCashBack'] = async (id) => {
    const { error: err } = await supabase.from('cash_backs').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const addTip: AppData['addTip'] = async (t) => {
    const { error: err } = await supabase.from('tips').insert(t);
    if (err) throw err;
    await refresh();
  };

  const deleteTip: AppData['deleteTip'] = async (id) => {
    const { error: err } = await supabase.from('tips').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const saveMethod: AppData['saveMethod'] = async (m) => {
    const { id, ...rest } = m;
    if (id) {
      const { error: err } = await supabase.from('payment_methods').update(rest).eq('id', id);
      if (err) throw err;
    } else {
      const maxOrder = methods.reduce((acc, x) => Math.max(acc, x.sort_order), 0);
      const { error: err } = await supabase.from('payment_methods').insert({ ...rest, sort_order: maxOrder + 1 });
      if (err) throw err;
    }
    await refresh();
  };

  const toggleMethod: AppData['toggleMethod'] = async (id, active) => {
    const { error: err } = await supabase.from('payment_methods').update({ active }).eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const deleteMethod: AppData['deleteMethod'] = async (id) => {
    const used = sales.some((s) => s.method_id === id);
    if (used) {
      throw new Error('No se puede eliminar: hay ventas registradas con este método. Puedes desactivarlo.');
    }
    const { error: err } = await supabase.from('payment_methods').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const addExpenses: AppData['addExpenses'] = async (values) => {
    const { error: err } = await supabase.from('expenses').insert(values);
    if (err) throw err;
    await refresh();
  };

  const deleteExpense: AppData['deleteExpense'] = async (id) => {
    const { error: err } = await supabase.from('expenses').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const saveCategory: AppData['saveCategory'] = async (c) => {
    if (c.id) {
      const { error: err } = await supabase.from('expense_categories').update({ name: c.name, kind: c.kind }).eq('id', c.id);
      if (err) throw err;
    } else {
      const maxOrder = expenseCategories.reduce((acc, x) => Math.max(acc, x.sort_order), 0);
      const { error: err } = await supabase.from('expense_categories').insert({ name: c.name, kind: c.kind, sort_order: maxOrder + 1 });
      if (err) throw err;
    }
    await refresh();
  };

  const deleteCategory: AppData['deleteCategory'] = async (id) => {
    const usedInExpenses = expenses.some((e) => e.category_id === id);
    const usedInSubcats = expenseSubcategories.some((s) => s.category_id === id);
    if (usedInExpenses || usedInSubcats) {
      throw new Error('No se puede eliminar: hay gastos o subcategorías que usan esta categoría.');
    }
    const { error: err } = await supabase.from('expense_categories').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const saveSubcategory: AppData['saveSubcategory'] = async (s) => {
    if (s.id) {
      const { error: err } = await supabase.from('expense_subcategories').update({ name: s.name, category_id: s.category_id }).eq('id', s.id);
      if (err) throw err;
    } else {
      const siblings = expenseSubcategories.filter((x) => x.category_id === s.category_id);
      const maxOrder = siblings.reduce((acc, x) => Math.max(acc, x.sort_order), 0);
      const { error: err } = await supabase.from('expense_subcategories').insert({ category_id: s.category_id, name: s.name, sort_order: maxOrder + 1 });
      if (err) throw err;
    }
    await refresh();
  };

  const deleteSubcategory: AppData['deleteSubcategory'] = async (id) => {
    const used = expenses.some((e) => e.subcategory_id === id);
    if (used) {
      throw new Error('No se puede eliminar: hay gastos registrados con esta subcategoría.');
    }
    const { error: err } = await supabase.from('expense_subcategories').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const saveSupplier: AppData['saveSupplier'] = async (s) => {
    if (s.id) {
      const { error: err } = await supabase.from('suppliers').update(s).eq('id', s.id);
      if (err) throw err;
    } else {
      const { error: err } = await supabase.from('suppliers').insert(s);
      if (err) throw err;
    }
    await refresh();
  };

  const deleteSupplier: AppData['deleteSupplier'] = async (id) => {
    const { error: err } = await supabase.from('suppliers').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  const saveOpeningBalance: AppData['saveOpeningBalance'] = async (o) => {
    const { error: err } = await supabase.from('opening_balances').upsert({ ...o, updated_at: new Date().toISOString() });
    if (err) throw err;
    await refresh();
  };

  const addBankMovements: AppData['addBankMovements'] = async (values) => {
    const { error: err } = await supabase.from('bank_movements').insert(values);
    if (err) throw err;
    await refresh();
  };

  const deleteBankMovement: AppData['deleteBankMovement'] = async (id) => {
    const { error: err } = await supabase.from('bank_movements').delete().eq('id', id);
    if (err) throw err;
    await refresh();
  };

  return {
    methods, sales, cashBacks, tips, expenses, expenseCategories, expenseSubcategories, suppliers, openingBalances, bankMovements, loading, error, refresh,
    addSales, updateSale, deleteSale,
    addCashBack, deleteCashBack, addTip, deleteTip,
    saveMethod, toggleMethod, deleteMethod,
    addExpenses, deleteExpense, saveCategory, deleteCategory, saveSubcategory, deleteSubcategory,
    saveSupplier, deleteSupplier, saveOpeningBalance, addBankMovements, deleteBankMovement,
  };
}
