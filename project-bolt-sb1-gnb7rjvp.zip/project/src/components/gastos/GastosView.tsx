import { useMemo, useState } from 'react';
import { Plus, Trash2, Search, SlidersHorizontal, Tags, ChevronDown, ChevronRight, Settings2, Pencil, X, Check } from 'lucide-react';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/Card';
import { Modal } from '@/components/ui/Modal';
import { Badge } from '@/components/Badge';
import { StatCard } from '@/components/StatCard';
import { ExpenseForm, type ExpenseFormValues } from '@/components/gastos/ExpenseForm';
import { formatUsd, formatBs, formatDate, toNumber, addDays, toISODate, todayISO } from '@/lib/format';
import type { PaymentMethod, Expense, ExpenseCategory, ExpenseSubcategory } from '@/lib/supabase';

interface Props {
  expenses: Expense[];
  methods: PaymentMethod[];
  categories: ExpenseCategory[];
  subcategories: ExpenseSubcategory[];
  onAddExpenses: (rows: ExpenseFormValues[]) => Promise<void>;
  onDeleteExpense: (id: string) => Promise<void>;
  onSaveCategory: (c: { id?: string; name: string; kind: 'operativo' | 'liquidaciones' }) => Promise<void>;
  onDeleteCategory: (id: string) => Promise<void>;
  onSaveSubcategory: (s: { id?: string; category_id: string; name: string }) => Promise<void>;
  onDeleteSubcategory: (id: string) => Promise<void>;
}

export function GastosView(props: Props) {
  const { expenses, methods, categories, subcategories } = props;
  const methodById = new Map(methods.map((m) => [m.id, m]));
  const catById = new Map(categories.map((c) => [c.id, c]));
  const subById = new Map(subcategories.map((s) => [s.id, s]));

  const [tab, setTab] = useState<'lista' | 'resumen' | 'categorias'>('lista');
  const [showForm, setShowForm] = useState(false);
  const [showCats, setShowCats] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const [since, setSince] = useState(() => toISODate(addDays(new Date(), -29)));
  const [until, setUntil] = useState(todayISO());
  const [providerSearch, setProviderSearch] = useState('');
  const [fCategory, setFCategory] = useState('');
  const [fSubcategory, setFSubcategory] = useState('');
  const [fMethod, setFMethod] = useState('');

  const filtered = useMemo(() => {
    return expenses.filter((e) => {
      if (since && e.expense_date < since) return false;
      if (until && e.expense_date > until) return false;
      if (fCategory && e.category_id !== fCategory) return false;
      if (fSubcategory && e.subcategory_id !== fSubcategory) return false;
      if (fMethod && e.method_id !== fMethod) return false;
      if (providerSearch.trim()) {
        const q = providerSearch.toLowerCase();
        if (!e.provider.toLowerCase().includes(q) && !(e.notes ?? '').toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [expenses, since, until, providerSearch, fCategory, fSubcategory, fMethod]);

  const totals = useMemo(() => {
    const usd = filtered.reduce((a, e) => a + e.amount_usd, 0);
    const ves = filtered.reduce((a, e) => a + e.amount_ves, 0);
    const opUsd = filtered.filter((e) => e.egress_type === 'operativo').reduce((a, e) => a + e.amount_usd, 0);
    const liqUsd = filtered.filter((e) => e.egress_type === 'vueltos_propinas').reduce((a, e) => a + e.amount_usd, 0);
    return { usd, ves, opUsd, liqUsd, count: filtered.length };
  }, [filtered]);

  const byCategory = useMemo(() => {
    const map = new Map<string, { usd: number; ves: number; count: number; subs: Map<string, { usd: number; ves: number; count: number }> }>();
    for (const e of filtered) {
      if (!e.category_id) continue;
      const cat = map.get(e.category_id) ?? { usd: 0, ves: 0, count: 0, subs: new Map() };
      cat.usd += e.amount_usd;
      cat.ves += e.amount_ves;
      cat.count += 1;
      if (e.subcategory_id) {
        const s = cat.subs.get(e.subcategory_id) ?? { usd: 0, ves: 0, count: 0 };
        s.usd += e.amount_usd;
        s.ves += e.amount_ves;
        s.count += 1;
        cat.subs.set(e.subcategory_id, s);
      }
      map.set(e.category_id, cat);
    }
    return [...map.entries()]
      .map(([id, v]) => ({ id, name: catById.get(id)?.name ?? '—', kind: catById.get(id)?.kind ?? 'operativo', ...v, subs: [...v.subs.entries()].map(([sid, sv]) => ({ id: sid, name: subById.get(sid)?.name ?? '—', ...sv })).sort((a, b) => b.usd - a.usd) }))
      .sort((a, b) => b.usd - a.usd);
  }, [filtered, categories, subcategories]);

  const fSubs = subcategories.filter((s) => !fCategory || s.category_id === fCategory);
  const inputCls = 'rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500';

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 rounded-xl bg-slate-100 p-1">
          {([
            ['lista', 'Registros'],
            ['resumen', 'Resumen de Gastos'],
            ['categorias', 'Categorías'],
          ] as [typeof tab, string][]).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`rounded-lg px-3.5 py-2 text-sm font-medium transition sm:px-4 ${tab === id ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {label}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="ml-auto flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-700 active:scale-[0.98] transition"
        >
          <Plus size={16} />
          Nuevo gasto
        </button>
      </div>

      {tab === 'lista' && (
        <>
          <Card>
            <CardHeader title="Filtros" icon={<SlidersHorizontal size={17} />} />
            <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Desde</label>
                <input type="date" value={since} onChange={(e) => setSince(e.target.value)} className={`${inputCls} w-full`} />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Hasta</label>
                <input type="date" value={until} onChange={(e) => setUntil(e.target.value)} className={`${inputCls} w-full`} />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Proveedor</label>
                <div className="relative">
                  <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="text" placeholder="Buscar…" value={providerSearch} onChange={(e) => setProviderSearch(e.target.value)} className={`${inputCls} w-full pl-8`} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Categoría</label>
                <select value={fCategory} onChange={(e) => { setFCategory(e.target.value); setFSubcategory(''); }} className={`${inputCls} w-full`}>
                  <option value="">Todas</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Subcategoría</label>
                <select value={fSubcategory} onChange={(e) => setFSubcategory(e.target.value)} className={`${inputCls} w-full`} disabled={!fCategory && fSubs.length === 0}>
                  <option value="">Todas</option>
                  {fSubs.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Método de pago</label>
                <select value={fMethod} onChange={(e) => setFMethod(e.target.value)} className={`${inputCls} w-full`}>
                  <option value="">Todos</option>
                  {methods.map((m) => (
                    <option key={m.id} value={m.id}>{m.name}</option>
                  ))}
                </select>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard title="Total del período (USD)" value={formatUsd(totals.usd)} sub={`${totals.count} registros`} icon={<span className="text-lg font-bold">$</span>} accent="rose" />
            <StatCard title="Total del período (Bs)" value={formatBs(totals.ves)} sub="Suma de equivalentes" icon={<span className="text-lg font-bold">Bs</span>} accent="blue" />
            <StatCard title="Gastos operativos" value={formatUsd(totals.opUsd)} sub="Insumos, nómina, servicios…" icon={<Tags size={18} />} accent="amber" />
            <StatCard title="Vueltos y propinas" value={formatUsd(totals.liqUsd)} sub="Liquidaciones registradas" icon={<span>％</span>} accent="emerald" />
          </div>

          <Card>
            <CardHeader title={`Gastos registrados (${filtered.length})`} />
            <CardContent className="p-0 overflow-x-auto">
              {filtered.length === 0 ? (
                <p className="text-center py-10 text-slate-400 text-sm">No hay gastos que coincidan con los filtros.</p>
              ) : (
                <table className="w-full text-sm min-w-[820px]">
                  <thead>
                    <tr className="text-left text-slate-500 border-b border-slate-100">
                      <th className="px-4 py-2.5 font-medium">Fecha</th>
                      <th className="px-4 py-2.5 font-medium">Tipo</th>
                      <th className="px-4 py-2.5 font-medium">Categoría / Sub</th>
                      <th className="px-4 py-2.5 font-medium">Proveedor</th>
                      <th className="px-4 py-2.5 font-medium">Método</th>
                      <th className="px-4 py-2.5 font-medium text-right">Monto</th>
                      <th className="px-4 py-2.5 font-medium text-right">USD</th>
                      <th className="px-4 py-2.5" />
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.slice(0, 100).map((e) => {
                      const m = methodById.get(e.method_id);
                      const cat = e.category_id ? catById.get(e.category_id) : null;
                      const sub = e.subcategory_id ? subById.get(e.subcategory_id) : null;
                      return (
                        <tr key={e.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                          <td className="px-4 py-2.5 text-slate-600 whitespace-nowrap">{formatDate(e.expense_date)}</td>
                          <td className="px-4 py-2.5">
                            <Badge variant={e.egress_type === 'operativo' ? 'amber' : 'blue'}>
                              {e.egress_type === 'operativo' ? 'Operativo' : 'Vueltos/Propinas'}
                            </Badge>
                          </td>
                          <td className="px-4 py-2.5 text-slate-600">
                            {cat?.name ?? '—'}
                            {sub && <span className="text-slate-400"> · {sub.name}</span>}
                          </td>
                          <td className="px-4 py-2.5 font-medium text-slate-700">{e.provider || '—'}</td>
                          <td className="px-4 py-2.5 text-slate-600">{m?.name ?? '—'}</td>
                          <td className="px-4 py-2.5 text-right tabular-nums font-medium">
                            {e.method_currency === 'USD' ? formatUsd(e.amount) : formatBs(e.amount)}
                          </td>
                          <td className="px-4 py-2.5 text-right tabular-nums text-rose-600 font-medium">{formatUsd(e.amount_usd)}</td>
                          <td className="px-4 py-2.5">
                            <div className="flex justify-end">
                              <button
                                onClick={() => setConfirmDelete(e.id)}
                                className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                                title="Eliminar"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </CardContent>
            {filtered.length > 100 && (
              <CardFooter>
                <p className="text-xs text-slate-400">Mostrando los primeros 100 de {filtered.length}. Ajusta los filtros para ver más.</p>
              </CardFooter>
            )}
          </Card>
        </>
      )}

      {tab === 'resumen' && (
        <Card>
          <CardHeader title="Resumen por categoría y subcategoría" icon={<Tags size={17} />} action={<Badge variant="gray">{formatUsd(totals.usd)} · {formatBs(totals.ves)}</Badge>} />
          <CardContent className="p-0">
            {byCategory.length === 0 ? (
              <p className="text-center py-10 text-slate-400 text-sm">Sin gastos en el período filtrado.</p>
            ) : (
              <div className="divide-y divide-slate-50">
                {byCategory.map((c) => (
                  <div key={c.id}>
                    <button
                      onClick={() => setExpanded(expanded === c.id ? null : c.id)}
                      className="w-full flex items-center gap-3 px-5 py-3.5 hover:bg-slate-50/60 transition-colors text-left"
                    >
                      {expanded === c.id ? <ChevronDown size={17} className="text-slate-400 shrink-0" /> : <ChevronRight size={17} className="text-slate-400 shrink-0" />}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-slate-800">{c.name}</span>
                          {c.kind === 'liquidaciones' && <Badge variant="blue">Vueltos/Propinas</Badge>}
                          <span className="text-xs text-slate-400">{c.count} reg.</span>
                        </div>
                        <p className="text-xs text-slate-400 tabular-nums mt-0.5">{formatBs(c.ves)}</p>
                      </div>
                      <span className="font-bold text-rose-600 tabular-nums shrink-0">{formatUsd(c.usd)}</span>
                    </button>
                    {expanded === c.id && c.subs.length > 0 && (
                      <div className="bg-slate-50/70">
                        {c.subs.map((s) => (
                          <div key={s.id} className="flex items-center justify-between gap-3 pl-12 pr-5 py-2 text-sm">
                            <span className="text-slate-600">{s.name} <span className="text-slate-400 text-xs">({s.count})</span></span>
                            <span className="flex items-center gap-4 tabular-nums">
                              <span className="text-slate-400 text-xs">{formatBs(s.ves)}</span>
                              <span className="font-medium text-rose-500">{formatUsd(s.usd)}</span>
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
          <CardFooter>
            <p className="text-xs text-slate-400">Toca una categoría para ver el desglose por subcategoría. Usa los filtros de la pestaña Registros para cambiar el período.</p>
          </CardFooter>
        </Card>
      )}

      {tab === 'categorias' && (
        <Card>
          <CardHeader
            title="Categorías y subcategorías"
            icon={<Settings2 size={17} />}
            action={
              <button onClick={() => setShowCats(true)} className="flex items-center gap-1.5 rounded-xl bg-slate-800 px-3.5 py-2 text-sm font-medium text-white hover:bg-slate-700 transition">
                <Tags size={15} />
                Gestionar
              </button>
            }
          />
          <CardContent className="p-0">
            <div className="divide-y divide-slate-50">
              {categories.map((c) => (
                <div key={c.id} className="px-5 py-4">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-slate-800">{c.name}</span>
                    <Badge variant={c.kind === 'operativo' ? 'amber' : 'blue'}>{c.kind === 'operativo' ? 'Operativo' : 'Vueltos/Propinas'}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {subcategories.filter((s) => s.category_id === c.id).map((s) => (
                      <span key={s.id} className="rounded-lg bg-slate-100 px-2 py-0.5 text-xs text-slate-600">{s.name}</span>
                    ))}
                    {subcategories.filter((s) => s.category_id === c.id).length === 0 && (
                      <span className="text-xs text-slate-400">Sin subcategorías.</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {showForm && (
        <ExpenseForm
          methods={methods}
          categories={categories}
          subcategories={subcategories}
          onClose={() => setShowForm(false)}
          onSubmit={props.onAddExpenses}
        />
      )}

      {showCats && (
        <CategoriesManager
          categories={categories}
          subcategories={subcategories}
          onSaveCategory={props.onSaveCategory}
          onDeleteCategory={props.onDeleteCategory}
          onSaveSubcategory={props.onSaveSubcategory}
          onDeleteSubcategory={props.onDeleteSubcategory}
          onClose={() => setShowCats(false)}
        />
      )}

      {confirmDelete && (
        <Modal title="Eliminar gasto" onClose={() => setConfirmDelete(null)}>
          <p className="text-sm text-slate-600">¿Seguro que deseas eliminar este registro de gasto? Esta acción no se puede deshacer.</p>
          <div className="flex gap-3 mt-4">
            <button onClick={() => setConfirmDelete(null)} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
              Cancelar
            </button>
            <button
              onClick={() => { props.onDeleteExpense(confirmDelete); setConfirmDelete(null); }}
              className="flex-1 rounded-xl bg-rose-600 py-2.5 text-sm font-semibold text-white hover:bg-rose-700 transition"
            >
              Eliminar
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function CategoriesManager({ categories, subcategories, onSaveCategory, onDeleteCategory, onSaveSubcategory, onDeleteSubcategory, onClose }: {
  categories: ExpenseCategory[];
  subcategories: ExpenseSubcategory[];
  onSaveCategory: (c: { id?: string; name: string; kind: 'operativo' | 'liquidaciones' }) => Promise<void>;
  onDeleteCategory: (id: string) => Promise<void>;
  onSaveSubcategory: (s: { id?: string; category_id: string; name: string }) => Promise<void>;
  onDeleteSubcategory: (id: string) => Promise<void>;
  onClose: () => void;
}) {
  const [newCat, setNewCat] = useState('');
  const [newCatKind, setNewCatKind] = useState<'operativo' | 'liquidaciones'>('operativo');
  const [subTargets, setSubTargets] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [editingSub, setEditingSub] = useState<{ id: string; name: string } | null>(null);

  async function addCategory() {
    if (!newCat.trim()) return;
    try {
      await onSaveCategory({ name: newCat.trim(), kind: newCatKind });
      setNewCat('');
      setError(null);
    } catch {
      setError('No se pudo crear la categoría. ¿El nombre ya existe?');
    }
  }

  async function addSub(catId: string) {
    const name = (subTargets[catId] ?? '').trim();
    if (!name) return;
    try {
      await onSaveSubcategory({ category_id: catId, name });
      setSubTargets((t) => ({ ...t, [catId]: '' }));
      setError(null);
    } catch {
      setError('No se pudo crear la subcategoría. ¿El nombre ya existe en esta categoría?');
    }
  }

  const inputCls = 'rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500';

  return (
    <Modal title="Gestionar categorías y subcategorías" onClose={onClose} wide>
      <div className="space-y-5">
        <div className="rounded-xl border border-slate-200 p-4 space-y-3">
          <p className="text-xs font-medium text-slate-500">Nueva categoría</p>
          <div className="flex flex-wrap gap-2">
            <input type="text" placeholder="Nombre de la categoría" value={newCat} onChange={(e) => setNewCat(e.target.value)} className={`${inputCls} flex-1 min-w-40`} />
            <select value={newCatKind} onChange={(e) => setNewCatKind(e.target.value as 'operativo' | 'liquidaciones')} className={inputCls}>
              <option value="operativo">Gasto Operativo</option>
              <option value="liquidaciones">Vueltos / Propinas</option>
            </select>
            <button onClick={addCategory} className="rounded-xl bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700 transition">
              Crear
            </button>
          </div>
        </div>

        {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

        <div className="space-y-3">
          {categories.map((c) => {
            const subs = subcategories.filter((s) => s.category_id === c.id);
            return (
              <div key={c.id} className="rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-slate-800">{c.name}</span>
                  <Badge variant={c.kind === 'operativo' ? 'amber' : 'blue'}>{c.kind === 'operativo' ? 'Operativo' : 'Vueltos/Propinas'}</Badge>
                  <button
                    onClick={() => { onDeleteCategory(c.id).catch(() => setError('No se pudo eliminar: hay gastos o subcategorías que la usan.')); }}
                    className="ml-auto p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                    title="Eliminar categoría"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
                <ul className="mt-2 space-y-1">
                  {subs.map((s) => (
                    <li key={s.id} className="flex items-center gap-2 text-sm">
                      {editingSub?.id === s.id ? (
                        <>
                          <input
                            type="text"
                            value={editingSub.name}
                            onChange={(e) => setEditingSub({ id: s.id, name: e.target.value })}
                            className="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                            autoFocus
                          />
                          <button
                            onClick={async () => { await onSaveSubcategory({ id: s.id, category_id: c.id, name: editingSub.name }); setEditingSub(null); }}
                            className="p-1 rounded-lg text-emerald-600 hover:bg-emerald-50"
                          >
                            <Check size={15} />
                          </button>
                          <button onClick={() => setEditingSub(null)} className="p-1 rounded-lg text-slate-400 hover:bg-slate-100">
                            <X size={15} />
                          </button>
                        </>
                      ) : (
                        <>
                          <span className="text-slate-600">{s.name}</span>
                          <button onClick={() => setEditingSub({ id: s.id, name: s.name })} className="p-1 rounded-lg text-slate-400 hover:bg-sky-50 hover:text-sky-600" title="Renombrar">
                            <Pencil size={13} />
                          </button>
                          <button
                            onClick={() => { onDeleteSubcategory(s.id).catch(() => setError('No se pudo eliminar: hay gastos con esta subcategoría.')); }}
                            className="p-1 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                            title="Eliminar subcategoría"
                          >
                            <Trash2 size={13} />
                          </button>
                        </>
                      )}
                    </li>
                  ))}
                </ul>
                <div className="flex gap-2 mt-3">
                  <input
                    type="text"
                    placeholder="Nueva subcategoría"
                    value={subTargets[c.id] ?? ''}
                    onChange={(e) => setSubTargets((t) => ({ ...t, [c.id]: e.target.value }))}
                    onKeyDown={(e) => { if (e.key === 'Enter') addSub(c.id); }}
                    className={`${inputCls} flex-1 min-w-40`}
                  />
                  <button onClick={() => addSub(c.id)} className="rounded-xl bg-slate-800 px-3.5 py-2 text-sm font-medium text-white hover:bg-slate-700 transition">
                    Agregar
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Modal>
  );
}
