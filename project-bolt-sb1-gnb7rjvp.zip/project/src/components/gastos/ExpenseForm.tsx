import { useMemo, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { toNumber, todayISO, formatUsd, formatBs } from '@/lib/format';
import type { PaymentMethod, ExpenseCategory, ExpenseSubcategory, Supplier } from '@/lib/supabase';

export interface ExpenseRow {
  key: string;
  egress_type: 'operativo' | 'vueltos_propinas';
  category_id: string;
  subcategory_id: string;
  provider: string;
  method_id: string;
  amount: string;
  notes: string;
}

export interface ExpenseFormValues {
  expense_date: string;
  bcv_rate: number;
  egress_type: 'operativo' | 'vueltos_propinas';
  category_id: string | null;
  subcategory_id: string | null;
  provider: string;
  method_id: string;
  amount: number;
  method_currency: 'VES' | 'USD';
  amount_usd: number;
  amount_ves: number;
  notes: string | null;
}

interface Props {
  methods: PaymentMethod[];
  categories: ExpenseCategory[];
  subcategories: ExpenseSubcategory[];
  suppliers: Supplier[];
  onClose: () => void;
  onSubmit: (rows: ExpenseFormValues[]) => Promise<void>;
}

export function ExpenseForm({ methods, categories, subcategories, suppliers, onClose, onSubmit }: Props) {
  const active = methods.filter((m) => m.active);
  const [mode, setMode] = useState<'individual' | 'bloque'>('individual');
  const [date, setDate] = useState(todayISO());
  const [rate, setRate] = useState('');
  const [shiftType, setShiftType] = useState<'operativo' | 'vueltos_propinas'>('operativo');
  const [rows, setRows] = useState<ExpenseRow[]>([
    { key: crypto.randomUUID(), egress_type: 'operativo', category_id: '', subcategory_id: '', provider: '', method_id: '', amount: '', notes: '' },
  ]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const nRate = toNumber(rate);

  function updateRow(key: string, patch: Partial<ExpenseRow>) {
    setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }

  function addRow() {
    setRows((rs) => [
      ...rs,
      { key: crypto.randomUUID(), egress_type: shiftType, category_id: '', subcategory_id: '', provider: '', method_id: '', amount: '', notes: '' },
    ]);
  }

  function removeRow(key: string) {
    setRows((rs) => (rs.length > 1 ? rs.filter((r) => r.key !== key) : rs));
  }

  function pickSupplier(key: string, supplierId: string) {
    const s = suppliers.find((x) => x.id === supplierId);
    if (!s) return;
    updateRow(key, { provider: s.name, category_id: s.default_category_id ?? '', subcategory_id: '' });
  }

  const computed = useMemo(
    () =>
      rows.map((r) => {
        const method = active.find((m) => m.id === r.method_id);
        const amt = toNumber(r.amount);
        const usd = method?.currency === 'USD' ? amt : nRate > 0 ? amt / nRate : 0;
        const ves = method?.currency === 'VES' ? amt : nRate > 0 ? amt * nRate : 0;
        return { row: r, method, amt, usd, ves };
      }),
    [rows, active, nRate]
  );

  async function handleSubmit() {
    if (!date || nRate <= 0) {
      setError('Indica la fecha y la tasa del día (Bs por USD).');
      return;
    }
    const valid = computed.filter((c) => c.method && c.amt > 0);
    if (valid.length === 0) {
      setError('Agrega al menos un registro con método de pago y monto mayor a cero.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const values: ExpenseFormValues[] = valid.map(({ row, method, amt, usd, ves }) => ({
        expense_date: date,
        bcv_rate: nRate,
        egress_type: row.egress_type,
        category_id: row.category_id || null,
        subcategory_id: row.subcategory_id || null,
        provider: row.provider.trim(),
        method_id: method!.id,
        amount: amt,
        method_currency: method!.currency,
        amount_usd: Math.round(usd * 100) / 100,
        amount_ves: Math.round(ves * 100) / 100,
        notes: row.notes.trim() || null,
      }));
      await onSubmit(values);
      onClose();
    } catch {
      setError('No se pudieron guardar los gastos. Intenta de nuevo.');
      setSaving(false);
    }
  }

  const inputCls = 'w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition';
  const cellCls = 'w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 transition min-w-0';

  return (
    <Modal title="Registrar gastos y salidas" onClose={onClose} wide>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setMode('individual')}
            className={`rounded-lg py-1.5 text-sm font-medium transition ${mode === 'individual' ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
          >
            Registro Individual
          </button>
          <button
            type="button"
            onClick={() => setMode('bloque')}
            className={`rounded-lg py-1.5 text-sm font-medium transition ${mode === 'bloque' ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
          >
            Carga por Bloque
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Fecha</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Tasa del día (Bs/USD)</label>
            <input type="number" step="0.0001" min="0" placeholder="Ej. 38.50" value={rate} onChange={(e) => setRate(e.target.value)} className={inputCls} />
          </div>
          <div className="col-span-2 sm:col-span-1">
            <label className="block text-xs font-medium text-slate-500 mb-1">Tipo de egreso</label>
            <select
              value={shiftType}
              onChange={(e) => {
                const v = e.target.value as 'operativo' | 'vueltos_propinas';
                setShiftType(v);
                if (mode === 'bloque') setRows((rs) => rs.map((r) => ({ ...r, egress_type: v })));
              }}
              className={inputCls}
            >
              <option value="operativo">Gasto Operativo</option>
              <option value="vueltos_propinas">Vueltos / Propinas</option>
            </select>
          </div>
        </div>

        {mode === 'bloque' ? (
          <div className="space-y-2">
            <div className="overflow-x-auto -mx-1 px-1">
              <table className="w-full text-sm min-w-[860px]">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100">
                    <th className="py-2 pr-2 font-medium">Categoría</th>
                    <th className="py-2 pr-2 font-medium">Subcategoría</th>
                    <th className="py-2 pr-2 font-medium">Proveedor</th>
                    <th className="py-2 pr-2 font-medium">Método</th>
                    <th className="py-2 pr-2 font-medium text-right">Monto</th>
                    <th className="py-2 pr-2 font-medium">Obs.</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {computed.map(({ row, method, usd }) => {
                    const subs = subcategories.filter((s) => s.category_id === row.category_id);
                    return (
                      <tr key={row.key} className="border-b border-slate-50">
                        <td className="py-1.5 pr-2">
                          <select value={row.category_id} onChange={(e) => updateRow(row.key, { category_id: e.target.value, subcategory_id: '' })} className={cellCls}>
                            <option value="">—</option>
                            {categories.filter((c) => (shiftType === 'operativo' ? c.kind === 'operativo' : true)).map((c) => (
                              <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                          </select>
                        </td>
                        <td className="py-1.5 pr-2">
                          <select value={row.subcategory_id} onChange={(e) => updateRow(row.key, { subcategory_id: e.target.value })} className={cellCls} disabled={!row.category_id}>
                            <option value="">—</option>
                            {subs.map((s) => (
                              <option key={s.id} value={s.id}>{s.name}</option>
                            ))}
                          </select>
                        </td>
                        <td className="py-1.5 pr-2">
                          <select value="" onChange={(e) => pickSupplier(row.key, e.target.value)} className={cellCls}>
                            <option value="">{row.provider ? 'Otro / libre' : 'Catálogo…'}</option>
                            {suppliers.map((s) => (
                              <option key={s.id} value={s.id}>{s.name}</option>
                            ))}
                          </select>
                          <input type="text" placeholder="Beneficiario" value={row.provider} onChange={(e) => updateRow(row.key, { provider: e.target.value })} className={`${cellCls} mt-1`} />
                        </td>
                        <td className="py-1.5 pr-2">
                          <select value={row.method_id} onChange={(e) => updateRow(row.key, { method_id: e.target.value })} className={cellCls}>
                            <option value="">—</option>
                            {active.map((m) => (
                              <option key={m.id} value={m.id}>{m.name} ({m.currency === 'VES' ? 'Bs' : 'USD'})</option>
                            ))}
                          </select>
                        </td>
                        <td className="py-1.5 pr-2">
                          <input type="number" step="0.01" min="0" placeholder="0.00" value={row.amount} onChange={(e) => updateRow(row.key, { amount: e.target.value })} className={`${cellCls} text-right`} />
                          {method && usd > 0 && (
                            <p className="text-[10px] text-slate-400 text-right mt-0.5">≈ {formatUsd(usd)}</p>
                          )}
                        </td>
                        <td className="py-1.5 pr-2">
                          <input type="text" placeholder="Nota" value={row.notes} onChange={(e) => updateRow(row.key, { notes: e.target.value })} className={cellCls} />
                        </td>
                        <td className="py-1.5">
                          <button type="button" onClick={() => removeRow(row.key)} className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500 transition-colors" title="Quitar fila">
                            <Trash2 size={15} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <button
              type="button"
              onClick={addRow}
              className="flex items-center gap-1.5 rounded-xl border border-dashed border-sky-300 bg-sky-50/60 px-4 py-2 text-sm font-medium text-sky-700 hover:bg-sky-100 transition"
            >
              <Plus size={16} />
              Agregar fila
            </button>
          </div>
        ) : (
          computed.length === 1 && (() => {
            const { row, method, usd, ves } = computed[0];
            const subs = subcategories.filter((s) => s.category_id === row.category_id);
            return (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Categoría</label>
                    <select value={row.category_id} onChange={(e) => updateRow(row.key, { category_id: e.target.value, subcategory_id: '' })} className={inputCls}>
                      <option value="">—</option>
                      {categories.filter((c) => (shiftType === 'operativo' ? c.kind === 'operativo' : true)).map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Subcategoría</label>
                    <select value={row.subcategory_id} onChange={(e) => updateRow(row.key, { subcategory_id: e.target.value })} className={inputCls} disabled={!row.category_id}>
                      <option value="">—</option>
                      {subs.map((s) => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Proveedor / Beneficiario</label>
                    {suppliers.length > 0 && (
                      <select value="" onChange={(e) => pickSupplier(row.key, e.target.value)} className={`${inputCls} mb-2`}>
                        <option value="">{row.provider ? 'Otro / libre' : 'Elegir del catálogo…'}</option>
                        {suppliers.map((s) => (
                          <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                      </select>
                    )}
                    <input type="text" placeholder="Ej. Carnicería La Plaza" value={row.provider} onChange={(e) => updateRow(row.key, { provider: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Método de pago</label>
                    <select value={row.method_id} onChange={(e) => updateRow(row.key, { method_id: e.target.value })} className={inputCls}>
                      <option value="">—</option>
                      {active.map((m) => (
                        <option key={m.id} value={m.id}>{m.name} ({m.currency === 'VES' ? 'Bs' : 'USD'})</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    Monto {method ? `(${method.currency === 'USD' ? 'USD' : 'Bs'})` : ''}
                  </label>
                  <input type="number" step="0.01" min="0" placeholder="Ej. 50.00" value={row.amount} onChange={(e) => updateRow(row.key, { amount: e.target.value })} className={inputCls} />
                  {method && (usd > 0 || ves > 0) && (
                    <p className="text-xs text-slate-400 mt-1">
                      ≈ {formatUsd(usd)} · {formatBs(ves)}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Observación (opcional)</label>
                  <input type="text" placeholder="Detalle adicional" value={row.notes} onChange={(e) => updateRow(row.key, { notes: e.target.value })} className={inputCls} />
                </div>
              </div>
            );
          })()
        )}

        {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={saving}
            className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
          >
            {saving ? 'Guardando…' : mode === 'bloque' ? `Guardar ${computed.filter((c) => c.method && c.amt > 0).length} registros` : 'Guardar gasto'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
