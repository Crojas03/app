import { useMemo, useState } from 'react';
import { CalendarRange, Trash2, Pencil, Check, X, Search, Calculator } from 'lucide-react';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/Card';
import { StatCard } from '@/components/StatCard';
import { Badge } from '@/components/Badge';
import { Modal } from '@/components/ui/Modal';
import { formatUsd, formatBs, formatDate, addDays, startOfMonth, endOfMonth, toISODate, todayISO, toNumber } from '@/lib/format';
import type { PaymentMethod, Sale, CashBack, Tip, Expense } from '@/lib/supabase';

interface Props {
  sales: Sale[];
  cashBacks: CashBack[];
  tips: Tip[];
  expenses: Expense[];
  methods: PaymentMethod[];
  onDeleteSale: (id: string) => void;
  onUpdateSale: (id: string, patch: Partial<Sale>) => void;
}

type QuickFilter = '10dias' | 'esteMes' | 'mesPasado' | 'todo' | 'custom';

interface PeriodTotals {
  grossUsd: number;
  grossVes: number;
  cashBacksUsd: number;
  tipsUsd: number;
  netUsd: number;
  dayShift: { usd: number; ves: number; count: number };
  nightShift: { usd: number; ves: number; count: number };
  byMethod: { id: string; name: string; currency: string; total: number; usd: number; count: number }[];
  count: number;
}

export function CierresView({ sales, cashBacks, tips, expenses, methods, onDeleteSale, onUpdateSale }: Props) {
  const [quick, setQuick] = useState<QuickFilter>('10dias');
  const [since, setSince] = useState(() => toISODate(addDays(new Date(), -9)));
  const [until, setUntil] = useState(todayISO());
  const [realGastosOpen, setRealGastosOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState({ amount: '', rate: '' });

  const methodById = new Map(methods.map((m) => [m.id, m]));

  const range = useMemo((): { since: string; until: string } => {
    const now = new Date();
    switch (quick) {
      case '10dias':
        return { since: toISODate(addDays(now, -9)), until: todayISO() };
      case 'esteMes':
        return { since: toISODate(startOfMonth(now)), until: toISODate(endOfMonth(now)) };
      case 'mesPasado': {
        const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        return { since: toISODate(startOfMonth(prev)), until: toISODate(endOfMonth(prev)) };
      }
      case 'todo':
        return { since: '2000-01-01', until: '2099-12-31' };
      case 'custom':
        return { since, until };
    }
  }, [quick, since, until]);

  const inRange = (d: string) => d >= range.since && d <= range.until;

  const totals: PeriodTotals = useMemo(() => {
    const fSales = sales.filter((s) => inRange(s.sale_date));
    const fCash = cashBacks.filter((c) => inRange(c.entry_date));
    const fTips = tips.filter((t) => inRange(t.entry_date));

    const grossUsd = fSales.reduce((a, s) => a + s.amount_usd, 0);
    const grossVes = fSales.reduce((a, s) => a + s.amount_ves, 0);
    const cashBacksUsd = fCash.reduce((a, c) => a + (c.currency === 'USD' ? c.amount : c.bcv_rate ? c.amount / c.bcv_rate : 0), 0);
    const tipsUsd = fTips.reduce((a, t) => a + (t.currency === 'USD' ? t.amount : t.bcv_rate ? t.amount / t.bcv_rate : 0), 0);

    const daySales = fSales.filter((s) => s.shift === 'diurno');
    const nightSales = fSales.filter((s) => s.shift === 'nocturno');

    const methodMap = new Map<string, { id: string; name: string; currency: string; total: number; usd: number; count: number }>();
    for (const s of fSales) {
      const m = methodById.get(s.method_id);
      const key = s.method_id;
      const prev = methodMap.get(key) ?? { id: key, name: m?.name ?? '—', currency: s.method_currency, total: 0, usd: 0, count: 0 };
      prev.total += s.amount;
      prev.usd += s.amount_usd;
      prev.count += 1;
      methodMap.set(key, prev);
    }

    return {
      grossUsd,
      grossVes,
      cashBacksUsd,
      tipsUsd,
      netUsd: grossUsd - cashBacksUsd - tipsUsd,
      dayShift: { usd: daySales.reduce((a, s) => a + s.amount_usd, 0), ves: daySales.reduce((a, s) => a + s.amount_ves, 0), count: daySales.length },
      nightShift: { usd: nightSales.reduce((a, s) => a + s.amount_usd, 0), ves: nightSales.reduce((a, s) => a + s.amount_ves, 0), count: nightSales.length },
      byMethod: [...methodMap.values()].sort((a, b) => b.usd - a.usd),
      count: fSales.length,
    };
  }, [sales, cashBacks, tips, range, methods]);

  const filteredSales = useMemo(() => {
    return sales
      .filter((s) => inRange(s.sale_date))
      .filter((s) => {
        if (!search.trim()) return true;
        const q = search.toLowerCase();
        const mName = methodById.get(s.method_id)?.name.toLowerCase() ?? '';
        return (
          s.sale_date.includes(q) ||
          s.shift.includes(q) ||
          mName.includes(q) ||
          String(s.amount).includes(q)
        );
      });
  }, [sales, range, search, methods]);

  const realTotals = useMemo(() => {
    const fExp = expenses.filter((e) => inRange(e.expense_date));
    const opUsd = fExp.filter((e) => e.egress_type === 'operativo').reduce((a, e) => a + e.amount_usd, 0);
    const opVes = fExp.filter((e) => e.egress_type === 'operativo').reduce((a, e) => a + e.amount_ves, 0);
    const liqUsd = fExp.filter((e) => e.egress_type === 'vueltos_propinas').reduce((a, e) => a + e.amount_usd, 0);
    const liqVes = fExp.filter((e) => e.egress_type === 'vueltos_propinas').reduce((a, e) => a + e.amount_ves, 0);
    return {
      opUsd, opVes, liqUsd, liqVes,
      realProfit: totals.netUsd - opUsd,
      count: fExp.length,
    };
  }, [expenses, range, totals.netUsd]);

  function applyCustom() {
    setQuick('custom');
  }

  return (
    <div className="space-y-5">
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            {([
              ['10dias', 'Últimos 10 días'],
              ['esteMes', 'Este mes'],
              ['mesPasado', 'Mes pasado'],
              ['todo', 'Todo'],
            ] as [QuickFilter, string][]).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setQuick(id)}
                className={`rounded-full px-3.5 py-1.5 text-sm font-medium transition ${
                  quick === id ? 'bg-sky-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-end gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Desde</label>
              <input
                type="date"
                value={quick === 'custom' ? since : range.since === '2000-01-01' ? '' : range.since}
                onChange={(e) => { setSince(e.target.value); setQuick('custom'); }}
                className="rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Hasta</label>
              <input
                type="date"
                value={quick === 'custom' ? until : range.until === '2099-12-31' ? '' : range.until}
                onChange={(e) => { setUntil(e.target.value); setQuick('custom'); }}
                className="rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
            <button
              onClick={applyCustom}
              className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 transition"
            >
              <CalendarRange size={16} />
              Aplicar rango
            </button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <StatCard
          title="Ventas Brutas (USD)"
          value={formatUsd(totals.grossUsd)}
          sub={`${totals.count} ventas registradas`}
          icon={<span className="text-lg font-bold">$</span>}
          accent="emerald"
        />
        <StatCard
          title="Ventas Brutas (Bs)"
          value={formatBs(totals.grossVes)}
          sub="Suma de equivalentes en bolívares"
          icon={<span className="text-lg font-bold">Bs</span>}
          accent="blue"
        />
        <StatCard
          title="Vueltos Entregados"
          value={formatUsd(totals.cashBacksUsd)}
          sub="Efectivo Bs y pago móvil, en USD"
          icon={<span>↩</span>}
          accent="amber"
        />
        <StatCard
          title="Propinas del Personal"
          value={formatUsd(totals.tipsUsd)}
          sub="Total entregado al personal"
          icon={<span>％</span>}
          accent="rose"
        />
        <StatCard
          title="Venta Neta del Período"
          value={formatUsd(totals.netUsd)}
          sub="Brutas − vueltos − propinas"
          icon={<span>Σ</span>}
          accent="blue"
        />
        <StatCard
          title="Gastos Operativos"
          value={formatUsd(realTotals.opUsd)}
          sub={realTotals.count > 0 ? `${realTotals.count} registros en Gastos` : 'Sin gastos registrados'}
          icon={<span>▲</span>}
          accent="rose"
        />
        <StatCard
          title="Vueltos y Propinas (Gastos)"
          value={formatUsd(realTotals.liqUsd)}
          sub="Por banco/PM; no se descuentan dos veces"
          icon={<span>％</span>}
          accent="amber"
        />
        <StatCard
          title="Utilidad Neta Real"
          value={formatUsd(realTotals.realProfit)}
          sub="Ventas Netas − Gastos Operativos"
          icon={<span>$</span>}
          accent="emerald"
        />
      </div>

      <Card>
        <CardHeader
          title="Cálculo de la Utilidad Neta Real"
          icon={<Calculator size={17} />}
          action={
            <button onClick={() => setRealGastosOpen(!realGastosOpen)} className="text-sm text-sky-600 hover:text-sky-700 font-medium">
              {realGastosOpen ? 'Ocultar detalle' : 'Ver detalle'}
            </button>
          }
        />
        {realGastosOpen && (
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-4 text-sm">
              <div className="rounded-xl bg-emerald-50 border border-emerald-100 p-3">
                <p className="text-xs text-emerald-700 font-medium">Ventas Netas</p>
                <p className="font-bold text-emerald-800 tabular-nums mt-0.5">{formatUsd(totals.netUsd)}</p>
                <p className="text-[10px] text-emerald-600/70 mt-0.5">Brutas − vueltos − propinas de turnos</p>
              </div>
              <div className="rounded-xl bg-rose-50 border border-rose-100 p-3">
                <p className="text-xs text-rose-700 font-medium">− Gastos Operativos</p>
                <p className="font-bold text-rose-800 tabular-nums mt-0.5">{formatUsd(realTotals.opUsd)}</p>
                <p className="text-[10px] text-rose-600/70 mt-0.5">{formatBs(realTotals.opVes)}</p>
              </div>
              <div className="rounded-xl bg-sky-50 border border-sky-100 p-3">
                <p className="text-xs text-sky-700 font-medium">Vueltos/Propinas en Gastos</p>
                <p className="font-bold text-sky-800 tabular-nums mt-0.5">{formatUsd(realTotals.liqUsd)}</p>
                <p className="text-[10px] text-sky-600/70 mt-0.5">No se descuentan dos veces</p>
              </div>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-3">
                <p className="text-xs text-slate-600 font-medium">= Utilidad Neta Real</p>
                <p className={`font-bold tabular-nums mt-0.5 ${realTotals.realProfit >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>{formatUsd(realTotals.realProfit)}</p>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader title="Desglose por turno" />
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-100">
                  <th className="px-5 py-2.5 font-medium">Turno</th>
                  <th className="px-5 py-2.5 font-medium text-right">Ventas</th>
                  <th className="px-5 py-2.5 font-medium text-right">USD</th>
                  <th className="px-5 py-2.5 font-medium text-right">Bs</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-50">
                  <td className="px-5 py-3"><Badge variant="amber">Diurno</Badge></td>
                  <td className="px-5 py-3 text-right text-slate-500">{totals.dayShift.count}</td>
                  <td className="px-5 py-3 text-right font-semibold text-emerald-700 tabular-nums">{formatUsd(totals.dayShift.usd)}</td>
                  <td className="px-5 py-3 text-right text-slate-600 tabular-nums">{formatBs(totals.dayShift.ves)}</td>
                </tr>
                <tr>
                  <td className="px-5 py-3"><Badge variant="blue">Nocturno</Badge></td>
                  <td className="px-5 py-3 text-right text-slate-500">{totals.nightShift.count}</td>
                  <td className="px-5 py-3 text-right font-semibold text-emerald-700 tabular-nums">{formatUsd(totals.nightShift.usd)}</td>
                  <td className="px-5 py-3 text-right text-slate-600 tabular-nums">{formatBs(totals.nightShift.ves)}</td>
                </tr>
              </tbody>
            </table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader title="Desglose por método de pago" />
          <CardContent className="p-0 max-h-72 overflow-y-auto">
            {totals.byMethod.length === 0 ? (
              <p className="text-center py-8 text-slate-400 text-sm">Sin ventas en este período.</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100">
                    <th className="px-5 py-2.5 font-medium">Método</th>
                    <th className="px-5 py-2.5 font-medium text-right">Ventas</th>
                    <th className="px-5 py-2.5 font-medium text-right">Total</th>
                    <th className="px-5 py-2.5 font-medium text-right">USD</th>
                  </tr>
                </thead>
                <tbody>
                  {totals.byMethod.map((m) => (
                    <tr key={m.id} className="border-b border-slate-50">
                      <td className="px-5 py-2.5 font-medium text-slate-700">{m.name}</td>
                      <td className="px-5 py-2.5 text-right text-slate-500">{m.count}</td>
                      <td className="px-5 py-2.5 text-right text-slate-600 tabular-nums">
                        {m.currency === 'USD' ? formatUsd(m.total) : formatBs(m.total)}
                      </td>
                      <td className="px-5 py-2.5 text-right font-medium text-emerald-700 tabular-nums">{formatUsd(m.usd)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader
          title={`Registros del período (${filteredSales.length})`}
          action={
            <div className="relative">
              <Search size={15} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar por fecha, turno, método…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-44 sm:w-64 rounded-xl border border-slate-300 pl-8 pr-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          }
        />
        <CardContent className="p-0 overflow-x-auto">
          {filteredSales.length === 0 ? (
            <p className="text-center py-10 text-slate-400 text-sm">No hay registros que coincidan.</p>
          ) : (
            <table className="w-full text-sm min-w-[720px]">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-100">
                  <th className="px-4 py-2.5 font-medium">Fecha</th>
                  <th className="px-4 py-2.5 font-medium">Turno</th>
                  <th className="px-4 py-2.5 font-medium">Método</th>
                  <th className="px-4 py-2.5 font-medium text-right">Monto</th>
                  <th className="px-4 py-2.5 font-medium text-right">Tasa</th>
                  <th className="px-4 py-2.5 font-medium text-right">USD</th>
                  <th className="px-4 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {filteredSales.slice(0, 100).map((s) => {
                  const m = methodById.get(s.method_id);
                  const isEditing = editingId === s.id;
                  return (
                    <tr key={s.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                      <td className="px-4 py-2.5 text-slate-600 whitespace-nowrap">{formatDate(s.sale_date)}</td>
                      <td className="px-4 py-2.5"><Badge variant={s.shift === 'diurno' ? 'amber' : 'blue'}>{s.shift === 'diurno' ? 'Diurno' : 'Nocturno'}</Badge></td>
                      <td className="px-4 py-2.5 font-medium text-slate-700">{m?.name ?? '—'}</td>
                      <td className="px-4 py-2.5 text-right tabular-nums font-medium">
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={editValues.amount}
                            onChange={(e) => setEditValues((v) => ({ ...v, amount: e.target.value }))}
                            className="w-24 rounded-lg border border-slate-300 px-2 py-1 text-right focus:outline-none focus:ring-2 focus:ring-sky-500"
                            autoFocus
                          />
                        ) : (
                          s.method_currency === 'USD' ? formatUsd(s.amount) : formatBs(s.amount)
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right tabular-nums text-slate-500">
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.0001"
                            min="0"
                            value={editValues.rate}
                            onChange={(e) => setEditValues((v) => ({ ...v, rate: e.target.value }))}
                            className="w-20 rounded-lg border border-slate-300 px-2 py-1 text-right focus:outline-none focus:ring-2 focus:ring-sky-500"
                          />
                        ) : (
                          s.bcv_rate.toFixed(2)
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right font-semibold text-emerald-700 tabular-nums">{formatUsd(s.amount_usd)}</td>
                      <td className="px-4 py-2.5">
                        <div className="flex justify-end gap-1">
                          {isEditing ? (
                            <>
                              <button
                                onClick={() => {
                                  const amt = toNumber(editValues.amount);
                                  const rate = toNumber(editValues.rate);
                                  if (amt <= 0 || rate <= 0) return;
                                  onUpdateSale(s.id, {
                                    amount: amt,
                                    bcv_rate: rate,
                                    amount_usd: s.method_currency === 'USD' ? amt : Math.round((amt / rate) * 100) / 100,
                                    amount_ves: s.method_currency === 'VES' ? amt : Math.round((amt * rate) * 100) / 100,
                                  });
                                  setEditingId(null);
                                }}
                                className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50"
                                title="Guardar"
                              >
                                <Check size={16} />
                              </button>
                              <button onClick={() => setEditingId(null)} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100" title="Cancelar">
                                <X size={16} />
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => { setEditingId(s.id); setEditValues({ amount: String(s.amount), rate: String(s.bcv_rate) }); }}
                                className="p-1.5 rounded-lg text-slate-400 hover:bg-sky-50 hover:text-sky-600 transition-colors"
                                title="Editar"
                              >
                                <Pencil size={16} />
                              </button>
                              <button
                                onClick={() => onDeleteSale(s.id)}
                                className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                                title="Eliminar"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
        {filteredSales.length > 100 && (
          <CardFooter>
            <p className="text-xs text-slate-400">Mostrando los primeros 100 registros de {filteredSales.length}. Ajusta el filtro para ver más.</p>
          </CardFooter>
        )}
      </Card>
    </div>
  );
}
