import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('bg-white rounded-2xl border border-slate-200 shadow-sm', className)}>
      {children}
    </div>
  );
}

export function CardContent({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn('p-5', className)}>{children}</div>;
}

export function CardHeader({ title, icon, action }: { title: string; icon?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-100">
      <div className="flex items-center gap-2.5 min-w-0">
        {icon && <span className="text-slate-500 shrink-0">{icon}</span>}
        <h3 className="font-semibold text-slate-800 truncate">{title}</h3>
      </div>
      {action}
    </div>
  );
}

export function CardFooter({ children }: { children: ReactNode }) {
  return <div className="px-5 py-3 bg-slate-50 rounded-b-2xl border-t border-slate-100">{children}</div>;
}
