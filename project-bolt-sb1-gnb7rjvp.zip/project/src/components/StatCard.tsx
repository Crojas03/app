import { ReactNode } from 'react';
import { Card, CardContent } from '@/components/ui/Card';
import { Skeleton } from '@/components/ui/Skeleton';

export function StatCard({ title, value, sub, icon, accent, loading }: {
  title: string;
  value: string;
  sub?: string;
  icon: ReactNode;
  accent?: 'blue' | 'amber' | 'emerald' | 'slate' | 'rose';
  loading?: boolean;
}) {
  const accents: Record<string, string> = {
    blue: 'bg-sky-100 text-sky-700',
    amber: 'bg-amber-100 text-amber-700',
    emerald: 'bg-emerald-100 text-emerald-700',
    slate: 'bg-slate-200 text-slate-700',
    rose: 'bg-rose-100 text-rose-700',
  };
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm text-slate-500 font-medium">{title}</p>
            {loading ? (
              <Skeleton className="h-7 w-28 mt-1.5" />
            ) : (
              <p className="text-xl md:text-2xl font-bold text-slate-800 mt-1 tabular-nums">{value}</p>
            )}
            {sub && !loading && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
          </div>
          <div className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${accents[accent ?? 'slate']}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
