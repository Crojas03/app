import { cn } from '@/lib/utils';

export function Badge({ children, variant }: { children: React.ReactNode; variant?: 'blue' | 'amber' | 'green' | 'gray' | 'red' }) {
  const variants: Record<string, string> = {
    blue: 'bg-sky-50 text-sky-700 ring-sky-200',
    amber: 'bg-amber-50 text-amber-700 ring-amber-200',
    green: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    gray: 'bg-slate-100 text-slate-600 ring-slate-200',
    red: 'bg-rose-50 text-rose-700 ring-rose-200',
  };
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset', variants[variant ?? 'gray'])}>
      {children}
    </span>
  );
}
