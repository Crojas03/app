import { useMemo, useState } from 'react';
import { Plus, Trash2, Landmark } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/Card';
import { Badge } from '@/components/Badge';
import { MOVEMENT_KINDS, type BankMovement } from '@/lib/supabase';
import { toNumber, todayISO, formatUsd, formatDate } from '@/lib/format';

export interface MovementFormValues {
  movement_date: string;
  account: string;
  kind: BankMovement['kind'];
  description: string | null;
  amount: number;
  currency: 'VES' | 'USD';
  bcv_rate: number;
  amount_usd: number;
  amount_ves: number;
}

interface Props {
  movements: BankMovement[];
  filterSince: string;
  filterUntil: string;
  onAdd: (values: MovementFormValues[]) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

interface Row {
  key: string;
  date: string;
  account: string;
  kind: BankMovement['kind'];
  description: string;
  amount: string;
  currency: 'VES' | 'USD';
  rate: string;
}

export function BankMovementsPanel({ movements, filterSince, filterUntil, onAdd, onDelete }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [rows, setRows] = useState<Row[]>([
    { key: crypto.randomUUID(), date: todayISO(), account: '', kind: 'venta_recibida', description: '', amount: '', currency: 'USD', rate: '' },
  ]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function updateRow(key: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }

  function addRow() {
    setRows((rs) => [
      ...rs,
      { key: crypto.randomUUID(), date: todayISO(), account: '', kind: 'venta_recibida', description: '', amount: '', currency: 'USD', rate: '' },
    ]);
  }

  function removeRow(key: string) {
    setRows((rs) => (rs.length > 1 ? rs.filter((r) => r.key !== key) : rs));
  }

  const computed = useMemo(
    () =>
      rows.map((r) => {
        const amt = toNumber(r.amount);
        const rate = toNumber(r.rate);
        const usd = r.currency === 'USD' ? amt : rate > 0 ? amt / rate : 0;
        const ves = r.currency === 'VES' ? amt : rate > 0 ? amt * rate : 0;
        return { row: r, amt, rate, usd, ves };
      }),
    [rows]
  );

  const filtered = movements.filter((m) => m.movement_date >= filterSince && m.movement_date <= filterUntil);

  const totalsByKind = useMemo(() => {
    const t: Record<BankMovement['kind'], number> = { venta_recibida: 0, comision: 0, compra_divisas: 0, adelanto_socios: 0, temporal: 0 };
    for (const m of filtered) t[m.kind] += m.amount_usd;
    return t;
  }, [filtered]);

  async function handleSubmit() {
    const valid = computed.filter((c) => c.amt > 0 && (c.row.currency === 'USD' || c.rate > 0));
    if (valid.length === 0) {
      setError('Agrega al menos un movimiento con monto y tasa válida (para Bs).');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const values: MovementFormValues[] = valid.map(({ row, amt, rate, usd, ves }) => ({
        movement_date: row.date || todayISO(),
        account: row.account.trim(),
        kind: row.kind,
        description: row.description.trim() || null,
        amount: amt,
        currency: row.currency,
        bcv_rate: rate,
        amount_usd: Math.round(usd * 100) / 100,
        amount_ves: Math.round(ves * 100) / 100,
      }));
      await onAdd(values);
      setShowForm(false);
    } catch {
      setError('No se pudieron guardar los movimientos. Intenta de nuevo.');
      setSaving(false);
    }
  }

  const inputCls = 'w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition';
  const cellCls = 'w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 transition min-w-0';

  return (
    <Card>
      <CardHeader
        title="Movimientos bancarios del período"
        icon={<Landmark size={17} />}
        action={
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-1.5 rounded-xl bg-sky-600 px-3.5 py-2 text-sm font-semibold text-white hover:bg-sky-700 transition shrink-0"
          >
            <Plus size={15} />
            Registrar
          </button>
        }
      />
      <CardContent className="p-0">
        <div className="grid grid-cols-2 sm:grid-cols-5 divide-x divide-y sm:divide-y-0 divide-slate-100 border-b border-slate-100">
          {MOVEMENT_KINDS.map(({ id, label }) => (
            <div key={id} className="p-3 text-center">
              <p className="text-[11px] text-slate-400 leading-tight">{label}</p>
              <p className="text-sm font-bold text-slate-700 tabular-nums mt-0.5">{formatUsd(totalsByKind[id])}</p>
            </div>
          ))}
        </div>
        {filtered.length === 0 ? (
          <p className="text-center py-8 text-slate-400 text-sm">Sin movimientos bancarios en este período.</p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {filtered.slice(0, 60).map((m) => (
              <li key={m.id} className="flex items-center gap-3 px-5 py-2.5 hover:bg-slate-50/60 transition-colors">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant={m.kind === 'venta_recibida' ? 'green' : m.kind === 'temporal' ? 'blue' : 'amber'}>
                      {MOVEMENT_KINDS.find((k) => k.id === m.kind)?.label ?? m.kind}
                    </Badge>
                    {m.account && <span className="text-xs text-slate-500">{m.account}</span>}
                    {m.description && <span className="text-xs text-slate-400">{m.description}</span>}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{formatDate(m.movement_date)}</p>
                </div>
                <span className="font-medium text-slate-700 tabular-nums shrink-0">{formatUsd(m.amount_usd)}</span>
                <button
                  onClick={() => onDelete(m.id)}
                  className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-600 transition-colors shrink-0"
                  title="Eliminar"
                >
                  <Trash2 size={15} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
      {filtered.length > 60 && (
        <CardFooter>
          <p className="text-xs text-slate-400">Mostrando los primeros 60 de {filtered.length} movimientos.</p>
        </CardFooter>
      )}

      {showForm && (
        <Modal title="Registrar movimientos bancarios" onClose={() => setShowForm(false)} wide>
          <div className="space-y-4">
            <div className="overflow-x-auto -mx-1 px-1">
              <table className="w-full text-sm min-w-[900px]">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100">
                    <th className="py-2 pr-2 font-medium">Fecha</th>
                    <th className="py-2 pr-2 font-medium">Cuenta</th>
                    <th className="py-2 pr-2 font-medium">Tipo</th>
                    <th className="py-2 pr-2 font-medium">Descripción</th>
                    <th className="py-2 pr-2 font-medium text-right">Monto</th>
                    <th className="py-2 pr-2 font-medium">Moneda</th>
                    <th className="py-2 pr-2 font-medium text-right">Tasa</th>
                    <th className="py-2 pr-2 font-medium text-right">USD</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {computed.map(({ row, usd }) => (
                    <tr key={row.key} className="border-b border-slate-50">
                      <td className="py-1.5 pr-2">
                        <input type="date" value={row.date} onChange={(e) => updateRow(row.key, { date: e.target.value })} className={cellCls} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <input type="text" placeholder="Ej. Banesco" value={row.account} onChange={(e) => updateRow(row.key, { account: e.target.value })} className={cellCls} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <select value={row.kind} onChange={(e) => updateRow(row.key, { kind: e.target.value as BankMovement['kind'] })} className={cellCls}>
                          {MOVEMENT_KINDS.map((k) => (
                            <option key={k.id} value={k.id}>{k.label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-1.5 pr-2">
                        <input type="text" placeholder="Detalle" value={row.description} onChange={(e) => updateRow(row.key, { description: e.target.value })} className={cellCls} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <input type="number" step="0.01" min="0" placeholder="0.00" value={row.amount} onChange={(e) => updateRow(row.key, { amount: e.target.value })} className={`${cellCls} text-right`} />
                      </td>
                      <td className="py-1.5 pr-2">
                        <select value={row.currency} onChange={(e) => updateRow(row.key, { currency: e.target.value as 'VES' | 'USD' })} className={cellCls}>
                          <option value="USD">USD</option>
                          <option value="VES">Bs</option>
                        </select>
                      </td>
                      <td className="py-1.5 pr-2">
                        <input type="number" step="0.0001" min="0" placeholder={row.currency === 'USD' ? '—' : '38.50'} value={row.rate} onChange={(e) => updateRow(row.key, { rate: e.target.value })} className={`${cellCls} text-right`} disabled={row.currency === 'USD'} />
                      </td>
                      <td className="py-1.5 pr-2 text-right tabular-nums">
                        {usd > 0 ? <span className="text-emerald-700 font-medium">{formatUsd(usd)}</span> : <span className="text-slate-300">—</span>}
                      </td>
                      <td className="py-1.5">
                        <button type="button" onClick={() => removeRow(row.key)} className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500 transition-colors" title="Quitar fila">
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button
              type="button"
              onClick={addRow}
              className="flex items-center gap-1.5 rounded-xl border border-dashed border-sky-300 bg-sky-50/60 px-4 py-2 text-sm font-medium text-sky-700 hover:bg-sky-100 transition"
            >
              <Plus size={16} />
              Agregar fila
            </button>

            {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

            <div className="flex gap-3 pt-1">
              <button type="button" onClick={() => setShowForm(false)} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={saving}
                className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
              >
                {saving ? 'Guardando…' : `Guardar ${computed.filter((c) => c.amt > 0).length} movimientos`}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </Card>
  );
}
