import { useMemo, useState } from 'react';
import { Wallet, Building2, Scale, AlertTriangle, CheckCircle2, PiggyBank, CalendarRange } from 'lucide-react';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/Card';
import { Modal } from '@/components/ui/Modal';
import { StatCard } from '@/components/StatCard';
import { Badge } from '@/components/Badge';
import { BankMovementsPanel, type MovementFormValues } from '@/components/resumen/BankMovementsPanel';
import { formatUsd, formatBs, toNumber, todayISO, toISODate, startOfMonth, endOfMonth } from '@/lib/format';
import type { Sale, Expense, ExpenseCategory, ExpenseSubcategory, BankMovement, OpeningBalance } from '@/lib/supabase';

interface Props {
  sales: Sale[];
  expenses: Expense[];
  categories: ExpenseCategory[];
  subcategories: ExpenseSubcategory[];
  movements: BankMovement[];
  openingBalances: OpeningBalance[];
  onSaveOpeningBalance: (o: { period_month: string; petty_cash_usd: number; petty_cash_ves: number; capital_usd: number; ref_rate: number }) => Promise<void>;
  onAddMovements: (values: MovementFormValues[]) => Promise<void>;
  onDeleteMovement: (id: string) => Promise<void>;
}

export function ResumenView(props: Props) {
  const { sales, expenses, categories, subcategories, movements, openingBalances } = props;
  const [since, setSince] = useState(() => toISODate(startOfMonth(new Date())));
  const [until, setUntil] = useState(() => toISODate(endOfMonth(new Date())));

  const periodMonth = since.slice(0, 7);
  const balance = openingBalances.find((b) => b.period_month === periodMonth);
  const [showBalances, setShowBalances] = useState(false);
  const [pettyUsd, setPettyUsd] = useState('');
  const [pettyVes, setPettyVes] = useState('');
  const [capital, setCapital] = useState('');
  const [refRate, setRefRate] = useState('');
  const [balError, setBalError] = useState<string | null>(null);
  const [balSaving, setBalSaving] = useState(false);

  function openBalances() {
    setPettyUsd(balance ? String(balance.petty_cash_usd) : '');
    setPettyVes(balance ? String(balance.petty_cash_ves) : '');
    setCapital(balance ? String(balance.capital_usd) : '');
    setRefRate(balance ? String(balance.ref_rate) : '');
    setBalError(null);
    setShowBalances(true);
  }

  async function handleSaveBalances() {
    setBalSaving(true);
    setBalError(null);
    try {
      await props.onSaveOpeningBalance({
        period_month: periodMonth,
        petty_cash_usd: toNumber(pettyUsd),
        petty_cash_ves: toNumber(pettyVes),
        capital_usd: toNumber(capital),
        ref_rate: toNumber(refRate),
      });
      setShowBalances(false);
    } catch {
      setBalError('No se pudieron guardar los saldos. Intenta de nuevo.');
      setBalSaving(false);
    }
  }

  const inRange = (d: string) => d >= since && d <= until;

  const data = useMemo(() => {
    const fSales = sales.filter((s) => inRange(s.sale_date));
    const fExp = expenses.filter((e) => inRange(e.expense_date));
    const fMov = movements.filter((m) => inRange(m.movement_date));

    const salesUsd = fSales.reduce((a, s) => a + s.amount_usd, 0);
    const expensesUsd = fExp.reduce((a, e) => a + e.amount_usd, 0);

    const pettyVesUsd = balance && balance.ref_rate > 0 ? balance.petty_cash_ves / balance.ref_rate : 0;
    const pettyCashTotalUsd = (balance?.petty_cash_usd ?? 0) + pettyVesUsd;
    const capitalUsd = balance?.capital_usd ?? 0;

    const bankSales = fMov.filter((m) => m.kind === 'venta_recibida').reduce((a, m) => a + m.amount_usd, 0);
    const bankComisions = fMov.filter((m) => m.kind === 'comision').reduce((a, m) => a + m.amount_usd, 0);
    const bankDivisas = fMov.filter((m) => m.kind === 'compra_divisas').reduce((a, m) => a + m.amount_usd, 0);
    const bankAdelantos = fMov.filter((m) => m.kind === 'adelanto_socios').reduce((a, m) => a + m.amount_usd, 0);
    const bankTemporal = fMov.filter((m) => m.kind === 'temporal').reduce((a, m) => a + m.amount_usd, 0);
    const bankExpenses = bankComisions + bankDivisas + bankAdelantos;
    const bankTotal = bankSales + bankExpenses;

    // El saldo esperado descuenta los movimientos temporales (vueltos/propinas
    // pasados por banco) porque ya salieron del efectivo del negocio.
    const expectedBalance = salesUsd + pettyCashTotalUsd + capitalUsd - expensesUsd - bankTemporal;
    const realBalance = fMov.reduce((a, m) => a + (m.kind === 'compra_divisas' || m.kind === 'adelanto_socios' ? 0 : m.kind === 'venta_recibida' ? m.amount_usd : -m.amount_usd), 0);

    const catMap = new Map<string, { usd: number; count: number; subs: Map<string, { usd: number; count: number }> }>();
    for (const e of fExp) {
      if (!e.category_id) continue;
      const cat = catMap.get(e.category_id) ?? { usd: 0, count: 0, subs: new Map() };
      cat.usd += e.amount_usd;
      cat.count += 1;
      if (e.subcategory_id) {
        const s = cat.subs.get(e.subcategory_id) ?? { usd: 0, count: 0 };
        s.usd += e.amount_usd;
        s.count += 1;
        cat.subs.set(e.subcategory_id, s);
      }
      catMap.set(e.category_id, cat);
    }

    return {
      salesUsd, expensesUsd, pettyCashTotalUsd, capitalUsd,
      bankSales, bankComisions, bankDivisas, bankAdelantos, bankTemporal, bankExpenses, bankTotal,
      salesDiff: salesUsd - bankSales,
      expensesDiff: expensesUsd - bankExpenses,
      expectedBalance, realBalance,
      balanceDiff: expectedBalance - realBalance,
      byCategory: [...catMap.entries()]
        .map(([id, v]) => ({
          id,
          name: categories.find((c) => c.id === id)?.name ?? '—',
          ...v,
          subs: [...v.subs.entries()].map(([sid, sv]) => ({ id: sid, name: subcategories.find((s) => s.id === sid)?.name ?? '—', ...sv })).sort((a, b) => b.usd - a.usd),
        }))
        .sort((a, b) => b.usd - a.usd),
    };
  }, [sales, expenses, movements, since, until, balance, categories, subcategories]);

  const inputCls = 'rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500';

  return (
    <div className="space-y-5">
      <Card>
        <CardContent className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Desde</label>
            <input type="date" value={since} onChange={(e) => setSince(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Hasta</label>
            <input type="date" value={until} onChange={(e) => setUntil(e.target.value)} className={inputCls} />
          </div>
          {balance && (balance.petty_cash_usd > 0 || balance.petty_cash_ves > 0 || balance.capital_usd > 0) ? (
            <div className="text-sm">
              <p className="text-slate-500">Caja Chica: <span className="font-semibold">{formatUsd(data.pettyCashTotalUsd)}</span></p>
              <p className="text-slate-500">Capital: <span className="font-semibold">{formatUsd(data.capitalUsd)}</span></p>
            </div>
          ) : (
            <p className="text-xs text-slate-400">Sin saldos iniciales configurados para este mes.</p>
          )}
          <button onClick={openBalances} className="ml-auto flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 transition">
            <PiggyBank size={16} />
            Saldos iniciales
          </button>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Ventas registradas (USD)" value={formatUsd(data.salesUsd)} sub="Sistema, en el período" icon={<span className="text-lg font-bold">$</span>} accent="emerald" />
        <StatCard title="Gastos registrados (USD)" value={formatUsd(data.expensesUsd)} sub="Sistema, en el período" icon={<span>▲</span>} accent="rose" />
        <StatCard title="Caja Chica + Capital inicial" value={formatUsd(data.pettyCashTotalUsd + data.capitalUsd)} sub={`Caja chica ${formatUsd(data.pettyCashTotalUsd)} · Capital ${formatUsd(data.capitalUsd)}`} icon={<Wallet size={18} />} accent="blue" />
        <StatCard title="Saldo esperado en bancos" value={formatUsd(data.expectedBalance)} sub="Ventas + Caja Chica + Capital − Gastos − Temporales" icon={<Building2 size={18} />} accent="blue" />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader title="Ventas: registradas vs. recibidas en bancos" icon={<Scale size={17} />} />
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">Ventas registradas en el sistema</span>
              <span className="font-bold text-slate-800 tabular-nums">{formatUsd(data.salesUsd)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">Ventas recibidas / conciliadas en bancos</span>
              <span className="font-bold text-slate-800 tabular-nums">{formatUsd(data.bankSales)}</span>
            </div>
            <div className={`flex items-center justify-between rounded-xl px-4 py-3 ${Math.abs(data.salesDiff) < 0.01 ? 'bg-emerald-50 border border-emerald-100' : 'bg-amber-50 border border-amber-200'}`}>
              <span className="text-sm font-medium text-slate-700">Diferencia</span>
              <span className={`font-bold tabular-nums ${Math.abs(data.salesDiff) < 0.01 ? 'text-emerald-700' : 'text-amber-700'}`}>
                {data.salesDiff >= 0 ? '+' : ''}{formatUsd(data.salesDiff).replace('$-', '-$')}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader title="Gastos: registrados vs. salidas en bancos" icon={<Scale size={17} />} />
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">Gastos registrados en el sistema</span>
              <span className="font-bold text-slate-800 tabular-nums">{formatUsd(data.expensesUsd)}</span>
            </div>
            <div className="rounded-xl bg-slate-50 border border-slate-200 divide-y divide-slate-100 text-sm">
              {([
                ['Comisiones', data.bankComisions],
                ['Compra de divisas', data.bankDivisas],
                ['Adelantos a socios', data.bankAdelantos],
              ] as [string, number][]).map(([label, v]) => (
                <div key={label} className="flex items-center justify-between px-3 py-2">
                  <span className="text-slate-500">{label}</span>
                  <span className="font-medium text-slate-700 tabular-nums">{formatUsd(v)}</span>
                </div>
              ))}
              <div className="flex items-center justify-between px-3 py-2">
                <span className="text-slate-500">Movimientos temporales (vueltos/propinas)</span>
                <span className="font-medium text-slate-700 tabular-nums">{formatUsd(data.bankTemporal)}</span>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-600">Salidas en bancos (sin temporales)</span>
              <span className="font-bold text-slate-800 tabular-nums">{formatUsd(data.bankExpenses)}</span>
            </div>
            <div className={`flex items-center justify-between rounded-xl px-4 py-3 ${Math.abs(data.expensesDiff) < 0.01 ? 'bg-emerald-50 border border-emerald-100' : 'bg-amber-50 border border-amber-200'}`}>
              <span className="text-sm font-medium text-slate-700">Diferencia</span>
              <span className={`font-bold tabular-nums ${Math.abs(data.expensesDiff) < 0.01 ? 'text-emerald-700' : 'text-amber-700'}`}>
                {data.expensesDiff >= 0 ? '+' : ''}{formatUsd(data.expensesDiff).replace('$-', '-$')}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <BankMovementsPanel
        movements={movements}
        filterSince={since}
        filterUntil={until}
        onAdd={props.onAddMovements}
        onDelete={props.onDeleteMovement}
      />

      <Card>
        <CardHeader title="Cuadre / Comprobación de saldo en bancos y cajas" icon={<CheckCircle2 size={17} />} />
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-5 text-sm">
            <div className="rounded-xl bg-emerald-50 border border-emerald-100 p-3 text-center">
              <p className="text-xs text-emerald-700 font-medium">+ Ventas</p>
              <p className="font-bold text-emerald-800 tabular-nums mt-0.5">{formatUsd(data.salesUsd)}</p>
            </div>
            <div className="rounded-xl bg-sky-50 border border-sky-100 p-3 text-center">
              <p className="text-xs text-sky-700 font-medium">+ Caja Chica</p>
              <p className="font-bold text-sky-800 tabular-nums mt-0.5">{formatUsd(data.pettyCashTotalUsd)}</p>
            </div>
            <div className="rounded-xl bg-sky-50 border border-sky-100 p-3 text-center">
              <p className="text-xs text-sky-700 font-medium">+ Capital</p>
              <p className="font-bold text-sky-800 tabular-nums mt-0.5">{formatUsd(data.capitalUsd)}</p>
            </div>
            <div className="rounded-xl bg-rose-50 border border-rose-100 p-3 text-center">
              <p className="text-xs text-rose-700 font-medium">− Gastos</p>
              <p className="font-bold text-rose-800 tabular-nums mt-0.5">{formatUsd(data.expensesUsd)}</p>
            </div>
            <div className={`rounded-xl p-3 text-center ${Math.abs(data.balanceDiff) < 0.01 ? 'bg-emerald-50 border border-emerald-100' : 'bg-amber-50 border border-amber-200'}`}>
              <p className="text-xs text-slate-600 font-medium">Saldo esperado</p>
              <p className="font-bold text-slate-800 tabular-nums mt-0.5">{formatUsd(data.expectedBalance)}</p>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-slate-50 border border-slate-200 p-4">
              <p className="text-xs text-slate-500 font-medium">Saldo reflejado en bancos / cajas</p>
              <p className="text-xl font-bold text-slate-800 tabular-nums mt-0.5">{formatUsd(data.realBalance)}</p>
              <p className="text-xs text-slate-400 mt-1">Suma de los movimientos registrados en la tabla de arriba.</p>
            </div>
            <div className={`rounded-xl p-4 ${Math.abs(data.balanceDiff) < 0.01 ? 'bg-emerald-50 border border-emerald-100' : 'bg-amber-50 border-2 border-amber-300'}`}>
              <div className="flex items-center gap-2">
                {Math.abs(data.balanceDiff) < 0.01 ? <CheckCircle2 size={18} className="text-emerald-600" /> : <AlertTriangle size={18} className="text-amber-600" />}
                <p className="text-xs font-medium text-slate-600">Diferencia (descuadre)</p>
              </div>
              <p className={`text-xl font-bold tabular-nums mt-0.5 ${Math.abs(data.balanceDiff) < 0.01 ? 'text-emerald-700' : 'text-amber-700'}`}>
                {data.balanceDiff >= 0 ? '+' : ''}{formatUsd(data.balanceDiff).replace('$-', '-$')}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {Math.abs(data.balanceDiff) < 0.01 ? 'Todo cuadra. No hay descuadre.' : 'Revisa movimientos faltantes o montos distintos.'}
              </p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <p className="text-xs text-slate-400">
            El saldo esperado resta además los movimientos temporales (vueltos y propinas pasados por banco), porque ese dinero ya salió del efectivo del negocio y no es un gasto nuevo.
          </p>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader title="Resumen de gastos por categoría y subcategoría (USD)" />
        <CardContent className="p-0">
          {data.byCategory.length === 0 ? (
            <p className="text-center py-8 text-slate-400 text-sm">Sin gastos en el período.</p>
          ) : (
            <div className="divide-y divide-slate-50">
              {data.byCategory.map((c) => (
                <div key={c.id} className="px-5 py-3.5">
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-semibold text-slate-800">{c.name} <span className="text-xs text-slate-400">({c.count} reg.)</span></span>
                    <span className="font-bold text-rose-600 tabular-nums">{formatUsd(c.usd)}</span>
                  </div>
                  {c.subs.length > 0 && (
                    <div className="mt-1.5 pl-4 space-y-1">
                      {c.subs.map((s) => (
                        <div key={s.id} className="flex items-center justify-between text-sm">
                          <span className="text-slate-500">{s.name} <span className="text-slate-400 text-xs">({s.count})</span></span>
                          <span className="font-medium text-rose-500 tabular-nums">{formatUsd(s.usd)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {showBalances && (
        <Modal title={`Saldos iniciales · ${periodMonth}`} onClose={() => setShowBalances(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Caja Chica inicial (USD)</label>
                <input type="number" step="0.01" min="0" placeholder="Ej. 200.00" value={pettyUsd} onChange={(e) => setPettyUsd(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Caja Chica inicial (Bs)</label>
                <input type="number" step="0.01" min="0" placeholder="Ej. 7000.00" value={pettyVes} onChange={(e) => setPettyVes(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Capital inicial (USD)</label>
                <input type="number" step="0.01" min="0" placeholder="Ej. 1000.00" value={capital} onChange={(e) => setCapital(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Tasa de referencia (Bs/USD)</label>
                <input type="number" step="0.0001" min="0" placeholder="Ej. 38.50" value={refRate} onChange={(e) => setRefRate(e.target.value)} className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500" />
              </div>
            </div>
            {toNumber(refRate) > 0 && toNumber(pettyVes) > 0 && (
              <p className="text-sm text-slate-500 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
                Caja Chica en Bs ≈ <span className="font-semibold text-slate-700">{formatUsd(toNumber(pettyVes) / toNumber(refRate))}</span> a la tasa de referencia.
              </p>
            )}
            {balError && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{balError}</p>}
            <div className="flex gap-3 pt-1">
              <button type="button" onClick={() => setShowBalances(false)} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveBalances}
                disabled={balSaving}
                className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
              >
                {balSaving ? 'Guardando…' : 'Guardar saldos'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
