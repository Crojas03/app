import { useState } from 'react';
import { Truck, Plus, Pencil, Trash2 } from 'lucide-react';
import { Card, CardHeader, CardContent } from '@/components/ui/Card';
import { Modal } from '@/components/ui/Modal';
import { Badge } from '@/components/Badge';
import type { Supplier, ExpenseCategory } from '@/lib/supabase';

interface Props {
  suppliers: Supplier[];
  categories: ExpenseCategory[];
  onSave: (s: { id?: string; name: string; tax_id: string | null; default_category_id: string | null; phone: string | null; notes: string | null }) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

export function SuppliersView({ suppliers, categories, onSave, onDelete }: Props) {
  const catById = new Map(categories.map((c) => [c.id, c]));
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [name, setName] = useState('');
  const [taxId, setTaxId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function openNew() {
    setEditing(null);
    setName('');
    setTaxId('');
    setCategoryId('');
    setPhone('');
    setNotes('');
    setError(null);
    setShowForm(true);
  }

  function openEdit(s: Supplier) {
    setEditing(s);
    setName(s.name);
    setTaxId(s.tax_id ?? '');
    setCategoryId(s.default_category_id ?? '');
    setPhone(s.phone ?? '');
    setNotes(s.notes ?? '');
    setError(null);
    setShowForm(true);
  }

  async function handleSave() {
    if (!name.trim()) {
      setError('Indica el nombre o razón social del proveedor.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSave({
        id: editing?.id,
        name: name.trim(),
        tax_id: taxId.trim() || null,
        default_category_id: categoryId || null,
        phone: phone.trim() || null,
        notes: notes.trim() || null,
      });
      setShowForm(false);
    } catch {
      setError('No se pudo guardar el proveedor. Intenta de nuevo.');
      setSaving(false);
    }
  }

  const inputCls = 'w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition';

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-slate-500">
          Catálogo de proveedores para seleccionar rápido al registrar gastos.
        </p>
        <button
          onClick={openNew}
          className="flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-700 active:scale-[0.98] transition shrink-0"
        >
          <Plus size={16} />
          Nuevo proveedor
        </button>
      </div>

      {suppliers.length === 0 ? (
        <Card>
          <CardContent className="text-center py-10 text-slate-400">
            No hay proveedores registrados todavía.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {suppliers.map((s) => (
            <Card key={s.id}>
              <CardHeader
                title={s.name}
                icon={<Truck size={18} />}
                action={
                  <div className="flex items-center gap-1">
                    <button onClick={() => openEdit(s)} className="p-1.5 rounded-lg text-slate-400 hover:bg-sky-50 hover:text-sky-600 transition-colors" title="Editar">
                      <Pencil size={15} />
                    </button>
                    <button
                      onClick={() => onDelete(s.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                }
              />
              <CardContent className="space-y-2 text-sm">
                {s.default_category_id && (
                  <div className="flex items-center gap-2">
                    <Badge variant="amber">{catById.get(s.default_category_id)?.name ?? '—'}</Badge>
                  </div>
                )}
                {s.tax_id && <p className="text-slate-600"><span className="text-slate-400">RIF:</span> {s.tax_id}</p>}
                {s.phone && <p className="text-slate-600"><span className="text-slate-400">Teléfono:</span> {s.phone}</p>}
                {s.notes && <p className="text-slate-500 text-xs">{s.notes}</p>}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showForm && (
        <Modal title={editing ? 'Editar proveedor' : 'Nuevo proveedor'} onClose={() => setShowForm(false)}>
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Nombre / Razón Social</label>
              <input type="text" placeholder="Ej. Carnicería La Plaza, C.A." value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">RIF / Identificación</label>
                <input type="text" placeholder="Ej. J-12345678-9" value={taxId} onChange={(e) => setTaxId(e.target.value)} className={inputCls} />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Teléfono</label>
                <input type="text" placeholder="Ej. 0416-1234567" value={phone} onChange={(e) => setPhone(e.target.value)} className={inputCls} />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Categoría habitual</label>
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className={inputCls}>
                <option value="">—</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Nota (opcional)</label>
              <input type="text" placeholder="Ej. Entrega los martes" value={notes} onChange={(e) => setNotes(e.target.value)} className={inputCls} />
            </div>
            {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}
            <div className="flex gap-3 pt-1">
              <button type="button" onClick={() => setShowForm(false)} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
              >
                {saving ? 'Guardando…' : 'Guardar proveedor'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
