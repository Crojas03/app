import { useState } from 'react';
import { Plus, Pencil, Trash2, Power, CreditCard } from 'lucide-react';
import { Card, CardHeader, CardContent } from '@/components/ui/Card';
import { Modal } from '@/components/ui/Modal';
import { Badge } from '@/components/Badge';
import type { PaymentMethod } from '@/lib/supabase';

interface Props {
  methods: PaymentMethod[];
  onSave: (m: { id?: string; name: string; currency: 'VES' | 'USD'; active: boolean; reconciliation_columns: string[] }) => Promise<void>;
  onToggle: (id: string, active: boolean) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

const DEFAULT_COLUMNS = ['Fecha', 'Referencia', 'Descripción', 'Monto'];

export function MetodosView({ methods, onSave, onToggle, onDelete }: Props) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<PaymentMethod | null>(null);
  const [name, setName] = useState('');
  const [currency, setCurrency] = useState<'VES' | 'USD'>('VES');
  const [columns, setColumns] = useState<string[]>(DEFAULT_COLUMNS);
  const [newColumn, setNewColumn] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  function openNew() {
    setEditing(null);
    setName('');
    setCurrency('VES');
    setColumns(DEFAULT_COLUMNS);
    setError(null);
    setShowForm(true);
  }

  function openEdit(m: PaymentMethod) {
    setEditing(m);
    setName(m.name);
    setCurrency(m.currency);
    setColumns(m.reconciliation_columns?.length ? m.reconciliation_columns : DEFAULT_COLUMNS);
    setError(null);
    setShowForm(true);
  }

  async function handleSave() {
    if (!name.trim()) {
      setError('Indica el nombre del método.');
      return;
    }
    if (columns.length === 0) {
      setError('Agrega al menos una columna para el estado de cuenta.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSave({ id: editing?.id, name: name.trim(), currency, active: editing?.active ?? true, reconciliation_columns: columns });
      setShowForm(false);
    } catch {
      setError('No se pudo guardar. ¿El nombre ya existe?');
      setSaving(false);
    }
  }

  function addColumn() {
    const c = newColumn.trim();
    if (c && !columns.includes(c)) setColumns([...columns, c]);
    setNewColumn('');
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-slate-500">
          Gestiona los métodos de pago y su plantilla de conciliación para la próxima etapa.
        </p>
        <button
          onClick={openNew}
          className="flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-700 active:scale-[0.98] transition shrink-0"
        >
          <Plus size={16} />
          Nuevo método
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {methods.map((m) => (
          <Card key={m.id} className={m.active ? '' : 'opacity-60'}>
            <CardHeader
              title={m.name}
              icon={<CreditCard size={18} />}
              action={
                <div className="flex items-center gap-1">
                  <button onClick={() => openEdit(m)} className="p-1.5 rounded-lg text-slate-400 hover:bg-sky-50 hover:text-sky-600 transition-colors" title="Editar">
                    <Pencil size={15} />
                  </button>
                  <button
                    onClick={() => { onDelete(m.id).catch(() => setDeletingId(m.id)); }}
                    className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              }
            />
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={m.currency === 'USD' ? 'green' : 'blue'}>{m.currency === 'USD' ? 'Dólares' : 'Bolívares'}</Badge>
                <Badge variant={m.active ? 'green' : 'gray'}>{m.active ? 'Activo' : 'Inactivo'}</Badge>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-400 mb-1.5">Columnas de estado de cuenta</p>
                <div className="flex flex-wrap gap-1.5">
                  {(m.reconciliation_columns?.length ? m.reconciliation_columns : DEFAULT_COLUMNS).map((c) => (
                    <span key={c} className="rounded-lg bg-slate-100 px-2 py-0.5 text-xs text-slate-600">{c}</span>
                  ))}
                </div>
              </div>
              <button
                onClick={() => onToggle(m.id, !m.active)}
                className={`w-full flex items-center justify-center gap-2 rounded-xl border py-2 text-sm font-medium transition ${
                  m.active
                    ? 'border-slate-200 text-slate-500 hover:bg-slate-50'
                    : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                <Power size={15} />
                {m.active ? 'Desactivar' : 'Activar'}
              </button>
            </CardContent>
          </Card>
        ))}
      </div>

      {showForm && (
        <Modal title={editing ? 'Editar método' : 'Nuevo método de pago'} onClose={() => setShowForm(false)}>
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Nombre</label>
              <input
                type="text"
                placeholder="Ej. PDV MercantilV"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Moneda del método</label>
              <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
                {(['VES', 'USD'] as const).map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCurrency(c)}
                    className={`rounded-lg py-1.5 text-sm font-medium transition ${currency === c ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
                  >
                    {c === 'VES' ? 'Bolívares (VES)' : 'Dólares (USD)'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">
                Columnas de la plantilla de conciliación
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {columns.map((c) => (
                  <span key={c} className="inline-flex items-center gap-1 rounded-lg bg-sky-50 text-sky-700 px-2 py-0.5 text-xs ring-1 ring-inset ring-sky-200">
                    {c}
                    <button onClick={() => setColumns(columns.filter((x) => x !== c))} className="hover:text-sky-900" title="Quitar">×</button>
                  </span>
                ))}
                {columns.length === 0 && <span className="text-xs text-slate-400">Sin columnas. Agrega al menos una.</span>}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Nueva columna (ej. Nº de lote)"
                  value={newColumn}
                  onChange={(e) => setNewColumn(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addColumn(); } }}
                  className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
                <button type="button" onClick={addColumn} className="rounded-xl bg-slate-800 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700 transition">
                  Agregar
                </button>
              </div>
            </div>

            {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

            <div className="flex gap-3 pt-1">
              <button type="button" onClick={() => setShowForm(false)} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
              >
                {saving ? 'Guardando…' : 'Guardar método'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {deletingId && (
        <Modal title="No se pudo eliminar" onClose={() => setDeletingId(null)}>
          <p className="text-sm text-slate-600">
            Hay ventas registradas con este método, por lo que no puede eliminarse. Puedes desactivarlo para dejar de usarlo.
          </p>
          <button
            onClick={() => setDeletingId(null)}
            className="mt-4 w-full rounded-xl bg-slate-800 py-2.5 text-sm font-semibold text-white hover:bg-slate-700 transition"
          >
            Entendido
          </button>
        </Modal>
      )}
    </div>
  );
}
