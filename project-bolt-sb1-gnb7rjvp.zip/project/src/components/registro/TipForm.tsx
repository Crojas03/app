import { useState } from 'react';
import { Modal } from '@/components/ui/Modal';
import { toNumber, todayISO } from '@/lib/format';
import type { Shift } from '@/lib/format';

export interface TipFormValues {
  entry_date: string;
  shift: Shift;
  person: string;
  amount: number;
  currency: 'VES' | 'USD';
  via: string;
  bank_account: string | null;
  bcv_rate: number | null;
}

interface Props {
  onClose: () => void;
  onSubmit: (values: TipFormValues) => Promise<void>;
}

export function TipForm({ onClose, onSubmit }: Props) {
  const [date, setDate] = useState(todayISO());
  const [shift, setShift] = useState<Shift>('diurno');
  const [person, setPerson] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<'VES' | 'USD'>('USD');
  const [via, setVia] = useState('');
  const [bank, setBank] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    const nAmount = toNumber(amount);
    if (!date || nAmount <= 0 || !via.trim()) {
      setError('Indica la fecha, el monto y la vía de entrada.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSubmit({
        entry_date: date,
        shift,
        person: person.trim() || 'Personal',
        amount: nAmount,
        currency,
        via: via.trim(),
        bank_account: bank.trim() || null,
        bcv_rate: null,
      });
      onClose();
    } catch {
      setError('No se pudo guardar la propina. Intenta de nuevo.');
      setSaving(false);
    }
  }

  const inputCls = 'w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition';

  return (
    <Modal title="Registrar propina" onClose={onClose}>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Fecha</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Turno</label>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              {(['diurno', 'nocturno'] as Shift[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShift(s)}
                  className={`rounded-lg py-1.5 text-sm font-medium transition ${shift === s ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  {s === 'diurno' ? 'Diurno' : 'Nocturno'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Beneficiario</label>
          <input type="text" placeholder="Nombre del personal (opcional)" value={person} onChange={(e) => setPerson(e.target.value)} className={inputCls} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Monto</label>
            <input type="number" step="0.01" min="0" placeholder="Ej. 5.00" value={amount} onChange={(e) => setAmount(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Moneda</label>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              {(['USD', 'VES'] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCurrency(c)}
                  className={`rounded-lg py-1.5 text-sm font-medium transition ${currency === c ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
                >
                  {c === 'VES' ? 'Bs' : 'USD'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Vía / cuenta de entrada</label>
          <input type="text" placeholder="Ej. Pago Móvil Banesco, Binance, Efectivo" value={via} onChange={(e) => setVia(e.target.value)} className={inputCls} />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Detalle de cuenta (opcional)</label>
          <input type="text" placeholder="Ej. 0416-1234567" value={bank} onChange={(e) => setBank(e.target.value)} className={inputCls} />
        </div>

        {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={saving}
            className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
          >
            {saving ? 'Guardando…' : 'Guardar propina'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
