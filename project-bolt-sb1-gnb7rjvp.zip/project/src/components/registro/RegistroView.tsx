import { useState } from 'react';
import { ShoppingCart, HandCoins, Gift, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/Card';
import { SaleForm, type SaleFormValues } from '@/components/registro/SaleForm';
import { CashBackForm, type CashBackFormValues } from '@/components/registro/CashBackForm';
import { TipForm, type TipFormValues } from '@/components/registro/TipForm';
import { SalesList } from '@/components/registro/SalesList';
import { ExtrasList } from '@/components/registro/ExtrasList';
import type { PaymentMethod, Sale, CashBack, Tip } from '@/lib/supabase';

interface Props {
  methods: PaymentMethod[];
  sales: Sale[];
  cashBacks: CashBack[];
  tips: Tip[];
  onAddSales: (v: SaleFormValues[]) => Promise<void>;
  onDeleteSale: (id: string) => void;
  onUpdateSale: (id: string, patch: Partial<Sale>) => void;
  onAddCashBack: (v: CashBackFormValues) => Promise<void>;
  onDeleteCashBack: (id: string) => void;
  onAddTip: (v: TipFormValues) => Promise<void>;
  onDeleteTip: (id: string) => void;
}

type Tab = 'ventas' | 'vueltos' | 'propinas';

export function RegistroView(props: Props) {
  const [tab, setTab] = useState<Tab>('ventas');
  const [showSaleForm, setShowSaleForm] = useState(false);
  const [showCashBackForm, setShowCashBackForm] = useState(false);
  const [showTipForm, setShowTipForm] = useState(false);

  const tabs: { id: Tab; label: string; icon: typeof ShoppingCart }[] = [
    { id: 'ventas', label: 'Ventas', icon: ShoppingCart },
    { id: 'vueltos', label: 'Vueltos', icon: HandCoins },
    { id: 'propinas', label: 'Propinas', icon: Gift },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 rounded-xl bg-slate-100 p-1">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium transition sm:px-4 ${
                tab === id ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <Icon size={16} />
              <span className="hidden xs:inline sm:inline">{label}</span>
            </button>
          ))}
        </div>
        <button
          onClick={() => (tab === 'ventas' ? setShowSaleForm(true) : tab === 'vueltos' ? setShowCashBackForm(true) : setShowTipForm(true))}
          className="ml-auto flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-sky-700 active:scale-[0.98] transition"
        >
          <Plus size={16} />
          {tab === 'ventas' ? 'Nueva venta' : tab === 'vueltos' ? 'Nuevo vuelto' : 'Nueva propina'}
        </button>
      </div>

      {props.methods.filter((m) => m.active).length === 0 ? (
        <Card>
          <CardContent className="text-center py-10 text-slate-400">
            No hay métodos de pago activos. Actívalos en la pestaña Métodos para poder registrar ventas.
          </CardContent>
        </Card>
      ) : tab === 'ventas' ? (
        <SalesList
          sales={props.sales}
          methods={props.methods}
          onDelete={props.onDeleteSale}
          onUpdate={props.onUpdateSale}
        />
      ) : (
        <ExtrasList
          cashBacks={props.cashBacks}
          tips={props.tips}
          onDeleteCashBack={props.onDeleteCashBack}
          onDeleteTip={props.onDeleteTip}
        />
      )}

          {showSaleForm && <SaleForm methods={props.methods} onClose={() => setShowSaleForm(false)} onSubmit={props.onAddSales} />}
      {showCashBackForm && <CashBackForm onClose={() => setShowCashBackForm(false)} onSubmit={props.onAddCashBack} />}
      {showTipForm && <TipForm onClose={() => setShowTipForm(false)} onSubmit={props.onAddTip} />}
    </div>
  );
}
