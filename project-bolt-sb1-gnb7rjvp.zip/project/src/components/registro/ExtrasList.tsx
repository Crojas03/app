import { Trash2 } from 'lucide-react';
import { Card, CardHeader, CardContent } from '@/components/ui/Card';
import { Badge } from '@/components/Badge';
import { formatDate, formatUsd, formatBs } from '@/lib/format';
import type { CashBack, Tip } from '@/lib/supabase';

interface Props {
  cashBacks: CashBack[];
  tips: Tip[];
  onDeleteCashBack: (id: string) => void;
  onDeleteTip: (id: string) => void;
  filterSince?: string | null;
  filterUntil?: string | null;
}

export function ExtrasList({ cashBacks, tips, onDeleteCashBack, onDeleteTip, filterSince, filterUntil }: Props) {
  const cb = cashBacks.filter((c) => {
    if (filterSince && c.entry_date < filterSince) return false;
    if (filterUntil && c.entry_date > filterUntil) return false;
    return true;
  });
  const tp = tips.filter((t) => {
    if (filterSince && t.entry_date < filterSince) return false;
    if (filterUntil && t.entry_date > filterUntil) return false;
    return true;
  });

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card>
        <CardHeader title={`Vueltos entregados (${cb.length})`} />
        <CardContent className="p-0">
          {cb.length === 0 ? (
            <p className="text-center py-8 text-slate-400 text-sm">Sin vueltos en este período.</p>
          ) : (
            <ul className="divide-y divide-slate-50">
              {cb.map((c) => (
                <li key={c.id} className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50/60 transition-colors">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-slate-800 tabular-nums">
                        {c.currency === 'USD' ? formatUsd(c.amount) : formatBs(c.amount)}
                      </span>
                      <Badge variant={c.shift === 'diurno' ? 'amber' : 'blue'}>{c.shift === 'diurno' ? 'Diurno' : 'Nocturno'}</Badge>
                      <Badge variant={c.delivery_method === 'efectivo_bs' ? 'gray' : 'green'}>
                        {c.delivery_method === 'efectivo_bs' ? 'Efectivo Bs' : 'Pago Móvil'}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {formatDate(c.entry_date)}
                      {c.bank_account ? ` · ${c.bank_account}` : ''}
                    </p>
                  </div>
                  <button
                    onClick={() => onDeleteCashBack(c.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader title={`Propinas del personal (${tp.length})`} />
        <CardContent className="p-0">
          {tp.length === 0 ? (
            <p className="text-center py-8 text-slate-400 text-sm">Sin propinas en este período.</p>
          ) : (
            <ul className="divide-y divide-slate-50">
              {tp.map((t) => (
                <li key={t.id} className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50/60 transition-colors">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-slate-800">{t.person}</span>
                      <span className="font-semibold text-emerald-700 tabular-nums">
                        {t.currency === 'USD' ? formatUsd(t.amount) : formatBs(t.amount)}
                      </span>
                      <Badge variant={t.shift === 'diurno' ? 'amber' : 'blue'}>{t.shift === 'diurno' ? 'Diurno' : 'Nocturno'}</Badge>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {formatDate(t.entry_date)} · {t.via}
                      {t.bank_account ? ` · ${t.bank_account}` : ''}
                    </p>
                  </div>
                  <button
                    onClick={() => onDeleteTip(t.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
