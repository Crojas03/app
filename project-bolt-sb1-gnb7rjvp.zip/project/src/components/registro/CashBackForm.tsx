import { useState } from 'react';
import { Modal } from '@/components/ui/Modal';
import { toNumber, todayISO } from '@/lib/format';
import type { Shift } from '@/lib/format';

export interface CashBackFormValues {
  entry_date: string;
  shift: Shift;
  amount: number;
  currency: 'VES' | 'USD';
  delivery_method: 'pago_movil' | 'efectivo_bs';
  bank_account: string | null;
  bcv_rate: number | null;
}

interface Props {
  onClose: () => void;
  onSubmit: (values: CashBackFormValues) => Promise<void>;
}

export function CashBackForm({ onClose, onSubmit }: Props) {
  const [date, setDate] = useState(todayISO());
  const [shift, setShift] = useState<Shift>('diurno');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<'VES' | 'USD'>('VES');
  const [via, setVia] = useState<'pago_movil' | 'efectivo_bs'>('pago_movil');
  const [bank, setBank] = useState('');
  const [rate, setRate] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    const nAmount = toNumber(amount);
    if (!date || nAmount <= 0) {
      setError('Indica la fecha y un monto mayor a cero.');
      return;
    }
    if (via === 'pago_movil' && !bank.trim()) {
      setError('Indica el banco o cuenta del pago móvil.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSubmit({
        entry_date: date,
        shift,
        amount: nAmount,
        currency: via === 'efectivo_bs' ? 'VES' : currency,
        delivery_method: via,
        bank_account: via === 'pago_movil' ? bank.trim() : null,
        bcv_rate: rate ? toNumber(rate) : null,
      });
      onClose();
    } catch {
      setError('No se pudo guardar el vuelto. Intenta de nuevo.');
      setSaving(false);
    }
  }

  const inputCls = 'w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition';

  return (
    <Modal title="Registrar vuelto" onClose={onClose}>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Fecha</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Turno</label>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              {(['diurno', 'nocturno'] as Shift[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShift(s)}
                  className={`rounded-lg py-1.5 text-sm font-medium transition ${shift === s ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  {s === 'diurno' ? 'Diurno' : 'Nocturno'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Monto</label>
            <input type="number" step="0.01" min="0" placeholder="Ej. 50.00" value={amount} onChange={(e) => setAmount(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Moneda</label>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              {(['VES', 'USD'] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  disabled={via === 'efectivo_bs'}
                  onClick={() => setCurrency(c)}
                  className={`rounded-lg py-1.5 text-sm font-medium transition disabled:opacity-50 ${currency === c ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
                >
                  {c === 'VES' ? 'Bs' : 'USD'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Vía de entrega</label>
          <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => setVia('pago_movil')}
              className={`rounded-lg py-1.5 text-sm font-medium transition ${via === 'pago_movil' ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
            >
              Pago Móvil
            </button>
            <button
              type="button"
              onClick={() => setVia('efectivo_bs')}
              className={`rounded-lg py-1.5 text-sm font-medium transition ${via === 'efectivo_bs' ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
            >
              Efectivo Bs
            </button>
          </div>
        </div>

        {via === 'pago_movil' && (
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Banco / cuenta</label>
            <input type="text" placeholder="Ej. Banesco · 0416-1234567" value={bank} onChange={(e) => setBank(e.target.value)} className={inputCls} />
          </div>
        )}

        {via === 'pago_movil' && currency === 'VES' && (
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Tasa BCV del turno (opcional)</label>
            <input type="number" step="0.0001" min="0" placeholder="Ej. 38.50" value={rate} onChange={(e) => setRate(e.target.value)} className={inputCls} />
          </div>
        )}

        {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={saving}
            className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
          >
            {saving ? 'Guardando…' : 'Guardar vuelto'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
