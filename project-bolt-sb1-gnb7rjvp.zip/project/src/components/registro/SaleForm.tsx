import { useMemo, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { toNumber, todayISO, formatUsd, formatBs } from '@/lib/format';
import type { PaymentMethod } from '@/lib/supabase';
import type { Shift } from '@/lib/format';

export interface SaleFormValues {
  sale_date: string;
  shift: Shift;
  bcv_rate: number;
  method_id: string;
  amount: number;
  method_currency: 'VES' | 'USD';
  amount_usd: number;
  amount_ves: number;
}

interface Row {
  key: string;
  method_id: string;
  amount: string;
}

interface Props {
  methods: PaymentMethod[];
  onClose: () => void;
  onSubmit: (values: SaleFormValues[]) => Promise<void>;
}

export function SaleForm({ methods, onClose, onSubmit }: Props) {
  const active = methods.filter((m) => m.active);
  const [mode, setMode] = useState<'individual' | 'bloque'>('individual');
  const [date, setDate] = useState(todayISO());
  const [shift, setShift] = useState<Shift>('diurno');
  const [rate, setRate] = useState('');
  const [rows, setRows] = useState<Row[]>([{ key: crypto.randomUUID(), method_id: '', amount: '' }]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const nRate = toNumber(rate);

  function updateRow(key: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }

  function addRow() {
    setRows((rs) => [...rs, { key: crypto.randomUUID(), method_id: '', amount: '' }]);
  }

  function removeRow(key: string) {
    setRows((rs) => (rs.length > 1 ? rs.filter((r) => r.key !== key) : rs));
  }

  const computed = useMemo(
    () =>
      rows.map((r) => {
        const method = active.find((m) => m.id === r.method_id);
        const amt = toNumber(r.amount);
        const usd = method?.currency === 'USD' ? amt : nRate > 0 ? amt / nRate : 0;
        const ves = method?.currency === 'VES' ? amt : nRate > 0 ? amt * nRate : 0;
        return { row: r, method, amt, usd, ves };
      }),
    [rows, active, nRate]
  );

  const blockTotalUsd = computed.reduce((a, c) => a + c.usd, 0);

  async function handleSubmit() {
    if (!date || nRate <= 0) {
      setError('Indica la fecha y la tasa BCV del turno (Bs por USD).');
      return;
    }
    const valid = computed.filter((c) => c.method && c.amt > 0);
    if (valid.length === 0) {
      setError('Agrega al menos una venta con método de pago y monto mayor a cero.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const values: SaleFormValues[] = valid.map(({ row, method, amt, usd, ves }) => ({
        sale_date: date,
        shift,
        bcv_rate: nRate,
        method_id: method!.id,
        amount: amt,
        method_currency: method!.currency,
        amount_usd: Math.round(usd * 100) / 100,
        amount_ves: Math.round(ves * 100) / 100,
      }));
      await onSubmit(values);
      onClose();
    } catch {
      setError('No se pudieron guardar las ventas. Intenta de nuevo.');
      setSaving(false);
    }
  }

  const inputCls = 'w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition';
  const cellCls = 'w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 transition min-w-0';

  return (
    <Modal title="Registrar ventas" onClose={onClose} wide={mode === 'bloque'}>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setMode('individual')}
            className={`rounded-lg py-1.5 text-sm font-medium transition ${mode === 'individual' ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
          >
            Registro Individual
          </button>
          <button
            type="button"
            onClick={() => setMode('bloque')}
            className={`rounded-lg py-1.5 text-sm font-medium transition ${mode === 'bloque' ? 'bg-white shadow text-slate-800' : 'text-slate-500'}`}
          >
            Carga por Bloque
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Fecha</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Turno</label>
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              {(['diurno', 'nocturno'] as Shift[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShift(s)}
                  className={`rounded-lg py-1.5 text-sm font-medium transition ${shift === s ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  {s === 'diurno' ? 'Diurno' : 'Nocturno'}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Tasa BCV del turno (Bs/USD)</label>
            <input type="number" step="0.0001" min="0" placeholder="Ej. 38.50" value={rate} onChange={(e) => setRate(e.target.value)} className={inputCls} />
          </div>
        </div>

        {mode === 'bloque' ? (
          <div className="space-y-2">
            <div className="overflow-x-auto -mx-1 px-1">
              <table className="w-full text-sm min-w-[560px]">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100">
                    <th className="py-2 pr-2 font-medium">Método de pago</th>
                    <th className="py-2 pr-2 font-medium text-right">Monto</th>
                    <th className="py-2 pr-2 font-medium text-right">Equivalente USD</th>
                    <th className="py-2" />
                  </tr>
                </thead>
                <tbody>
                  {computed.map(({ row, method, amt, usd }) => (
                    <tr key={row.key} className="border-b border-slate-50">
                      <td className="py-1.5 pr-2">
                        <select value={row.method_id} onChange={(e) => updateRow(row.key, { method_id: e.target.value })} className={cellCls}>
                          <option value="">—</option>
                          {active.map((m) => (
                            <option key={m.id} value={m.id}>{m.name} ({m.currency === 'VES' ? 'Bs' : 'USD'})</option>
                          ))}
                        </select>
                      </td>
                      <td className="py-1.5 pr-2">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder={method?.currency === 'USD' ? '25.00' : '950.00'}
                          value={row.amount}
                          onChange={(e) => updateRow(row.key, { amount: e.target.value })}
                          className={`${cellCls} text-right`}
                        />
                      </td>
                      <td className="py-1.5 pr-2 text-right tabular-nums">
                        {method && amt > 0 ? (
                          <span className="text-emerald-700 font-medium">{formatUsd(usd)}</span>
                        ) : (
                          <span className="text-slate-300">—</span>
                        )}
                      </td>
                      <td className="py-1.5">
                        <button type="button" onClick={() => removeRow(row.key)} className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500 transition-colors" title="Quitar fila">
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <button
                type="button"
                onClick={addRow}
                className="flex items-center gap-1.5 rounded-xl border border-dashed border-sky-300 bg-sky-50/60 px-4 py-2 text-sm font-medium text-sky-700 hover:bg-sky-100 transition"
              >
                <Plus size={16} />
                Agregar fila
              </button>
              <p className="text-sm text-slate-500">
                Total del bloque: <span className="font-bold text-emerald-700 tabular-nums">{formatUsd(blockTotalUsd)}</span>
                {nRate > 0 && <span className="text-slate-400 tabular-nums"> · {formatBs(blockTotalUsd * nRate)}</span>}
              </p>
            </div>
          </div>
        ) : (
          computed.length === 1 && (() => {
            const { row, method, usd, ves } = computed[0];
            return (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Método de pago</label>
                  <select value={row.method_id} onChange={(e) => updateRow(row.key, { method_id: e.target.value })} className={inputCls}>
                    <option value="">—</option>
                    {active.map((m) => (
                      <option key={m.id} value={m.id}>{m.name} ({m.currency === 'VES' ? 'Bs' : 'USD'})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    Monto {method ? `(${method.currency === 'USD' ? 'USD' : 'Bs'})` : ''}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder={method?.currency === 'USD' ? 'Ej. 25.00' : 'Ej. 950.00'}
                    value={row.amount}
                    onChange={(e) => updateRow(row.key, { amount: e.target.value })}
                    className={inputCls}
                  />
                </div>
                <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-xs text-slate-500">Equivalente en USD</p>
                    <p className="font-bold text-emerald-700 tabular-nums">{usd > 0 ? formatUsd(usd) : '—'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Equivalente en Bs</p>
                    <p className="font-bold text-slate-700 tabular-nums">{ves > 0 ? formatBs(ves) : '—'}</p>
                  </div>
                </div>
              </div>
            );
          })()
        )}

        {error && <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>}

        <div className="flex gap-3 pt-1">
          <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50 transition">
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={saving}
            className="flex-1 rounded-xl bg-sky-600 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition disabled:opacity-60"
          >
            {saving ? 'Guardando…' : mode === 'bloque' ? `Guardar ${computed.filter((c) => c.method && c.amt > 0).length} ventas` : 'Guardar venta'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
