import { useState } from 'react';
import { Trash2, Pencil, Check, X } from 'lucide-react';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/Card';
import { Badge } from '@/components/Badge';
import { formatUsd, formatBs, formatDate } from '@/lib/format';
import type { PaymentMethod, Sale } from '@/lib/supabase';

interface Props {
  sales: Sale[];
  methods: PaymentMethod[];
  onDelete: (id: string) => void;
  onUpdate: (id: string, patch: Partial<Sale>) => void;
  filterSince?: string | null;
  filterUntil?: string | null;
}

export function SalesList({ sales, methods, onDelete, onUpdate, filterSince, filterUntil }: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState('');

  const methodById = new Map(methods.map((m) => [m.id, m]));
  const filtered = sales.filter((s) => {
    if (filterSince && s.sale_date < filterSince) return false;
    if (filterUntil && s.sale_date > filterUntil) return false;
    return true;
  });

  if (filtered.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-10 text-slate-400">
          No hay ventas registradas en este período.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader title={`Ventas del período (${filtered.length})`} />
      <CardContent className="p-0 overflow-x-auto">
        <table className="w-full text-sm min-w-[760px]">
          <thead>
            <tr className="text-left text-slate-500 border-b border-slate-100">
              <th className="px-4 py-2.5 font-medium">Fecha</th>
              <th className="px-4 py-2.5 font-medium">Turno</th>
              <th className="px-4 py-2.5 font-medium">Método</th>
              <th className="px-4 py-2.5 font-medium text-right">Monto original</th>
              <th className="px-4 py-2.5 font-medium text-right">Tasa BCV</th>
              <th className="px-4 py-2.5 font-medium text-right">USD</th>
              <th className="px-4 py-2.5 font-medium text-right">Bs</th>
              <th className="px-4 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {filtered.map((s) => {
              const method = methodById.get(s.method_id);
              const isEditing = editingId === s.id;
              return (
                <tr key={s.id} className="border-b border-slate-50 hover:bg-slate-50/60 transition-colors">
                  <td className="px-4 py-2.5 text-slate-600 whitespace-nowrap">{formatDate(s.sale_date)}</td>
                  <td className="px-4 py-2.5">
                    <Badge variant={s.shift === 'diurno' ? 'amber' : 'blue'}>{s.shift === 'diurno' ? 'Diurno' : 'Nocturno'}</Badge>
                  </td>
                  <td className="px-4 py-2.5">
                    <span className="font-medium text-slate-700">{method?.name ?? '—'}</span>
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums">
                    {isEditing ? (
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={editAmount}
                        onChange={(e) => setEditAmount(e.target.value)}
                        className="w-28 rounded-lg border border-slate-300 px-2 py-1 text-right focus:outline-none focus:ring-2 focus:ring-sky-500"
                        autoFocus
                      />
                    ) : (
                      <span className="font-medium text-slate-800">
                        {s.method_currency === 'USD' ? formatUsd(s.amount) : formatBs(s.amount)}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-500">{s.bcv_rate.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums font-medium text-emerald-700">{formatUsd(s.amount_usd)}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-600">{formatBs(s.amount_ves)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-1">
                      {isEditing ? (
                        <>
                          <button
                            onClick={() => {
                              const amt = parseFloat(editAmount.replace(',', '.'));
                              if (!Number.isFinite(amt) || amt <= 0) return;
                              const rate = s.bcv_rate;
                              onUpdate(s.id, {
                                amount: amt,
                                amount_usd: s.method_currency === 'USD' ? amt : Math.round((amt / rate) * 100) / 100,
                                amount_ves: s.method_currency === 'VES' ? amt : Math.round((amt * rate) * 100) / 100,
                              });
                              setEditingId(null);
                            }}
                            className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50"
                            title="Guardar"
                          >
                            <Check size={16} />
                          </button>
                          <button onClick={() => setEditingId(null)} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100" title="Cancelar">
                            <X size={16} />
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => { setEditingId(s.id); setEditAmount(String(s.amount)); }}
                            className="p-1.5 rounded-lg text-slate-400 hover:bg-sky-50 hover:text-sky-600 transition-colors"
                            title="Editar monto"
                          >
                            <Pencil size={16} />
                          </button>
                          <button
                            onClick={() => onDelete(s.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                            title="Eliminar"
                          >
                            <Trash2 size={16} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardContent>
      <CardFooter>
        <p className="text-xs text-slate-400">Los montos se muestran en la moneda original del método, con su equivalente calculado a la tasa del turno.</p>
      </CardFooter>
    </Card>
  );
}
