/*
# Métodos de pago iniciales

Inserta la lista inicial de 14 métodos de pago con su moneda. Idempotente:
usa ON CONFLICT (name) DO NOTHING para no duplicar en re-ejecuciones.
*/

INSERT INTO payment_methods (name, currency, active, sort_order) VALUES
  ('PDV Venezuela', 'VES', true, 1),
  ('PDV Banesco', 'VES', true, 2),
  ('PM BNCE', 'VES', true, 3),
  ('PDV BNCL', 'VES', true, 4),
  ('PDV MercantilV', 'VES', true, 5),
  ('PDV BNC', 'VES', true, 6),
  ('PM Banesco', 'VES', true, 7),
  ('PM BNCL', 'VES', true, 8),
  ('Efectivo Dólares', 'USD', true, 9),
  ('Efectivo Bs', 'VES', true, 10),
  ('PayPal', 'USD', true, 11),
  ('Binance', 'USD', true, 12),
  ('Yummy', 'USD', true, 13),
  ('Yape', 'USD', true, 14)
ON CONFLICT (name) DO NOTHING;