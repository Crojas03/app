/*
# Proveedores, saldos iniciales y movimientos bancarios

1. Nuevas tablas
- `suppliers`: catálogo de proveedores (nombre/razón social, RIF/identificación,
  categoría habitual, teléfono, nota).
- `opening_balances`: saldos iniciales por mes (clave 'YYYY-MM'): caja chica
  inicial en USD, caja chica inicial en Bs, capital inicial en USD y tasa de
  referencia para convertir los bolívares.
- `bank_movements`: movimientos bancarios para la comprobación: fecha, cuenta,
  tipo (venta_recibida, comision, compra_divisas, adelanto_socios, temporal),
  descripción, monto, moneda, tasa y equivalentes USD/Bs.

2. Seguridad
- RLS habilitado en las 3 tablas.
- Políticas TO anon, authenticated USING(true) (app single-tenant sin auth,
  igual que el resto).
- GRANT de CRUD a anon + authenticated.

3. Notas
- expenses.provider sigue siendo texto libre; el formulario lo llenará desde
  el catálogo de proveedores. No se modifican tablas existentes.
- opening_balances usa period_month como clave primaria de texto ('YYYY-MM')
  y se edita con upsert (ON CONFLICT).
*/

CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  tax_id text,
  default_category_id uuid REFERENCES expense_categories(id) ON DELETE SET NULL,
  phone text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS opening_balances (
  period_month text PRIMARY KEY CHECK (period_month ~ '^\d{4}-\d{2}$'),
  petty_cash_usd numeric(14,2) NOT NULL DEFAULT 0,
  petty_cash_ves numeric(14,2) NOT NULL DEFAULT 0,
  capital_usd numeric(14,2) NOT NULL DEFAULT 0,
  ref_rate numeric(14,4) NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bank_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  movement_date date NOT NULL,
  account text NOT NULL DEFAULT '',
  kind text NOT NULL CHECK (kind IN ('venta_recibida', 'comision', 'compra_divisas', 'adelanto_socios', 'temporal')),
  description text,
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  currency text NOT NULL CHECK (currency IN ('VES', 'USD')),
  bcv_rate numeric(14,4) NOT NULL DEFAULT 0,
  amount_usd numeric(14,2) NOT NULL,
  amount_ves numeric(14,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bank_movements_date ON bank_movements (movement_date);
CREATE INDEX IF NOT EXISTS idx_bank_movements_kind ON bank_movements (kind);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE opening_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_movements ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON suppliers TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON opening_balances TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON bank_movements TO anon, authenticated;

DROP POLICY IF EXISTS "sup_select" ON suppliers;
CREATE POLICY "sup_select" ON suppliers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "sup_insert" ON suppliers;
CREATE POLICY "sup_insert" ON suppliers FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "sup_update" ON suppliers;
CREATE POLICY "sup_update" ON suppliers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "sup_delete" ON suppliers;
CREATE POLICY "sup_delete" ON suppliers FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "ob_select" ON opening_balances;
CREATE POLICY "ob_select" ON opening_balances FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ob_insert" ON opening_balances;
CREATE POLICY "ob_insert" ON opening_balances FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ob_update" ON opening_balances;
CREATE POLICY "ob_update" ON opening_balances FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ob_delete" ON opening_balances;
CREATE POLICY "ob_delete" ON opening_balances FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "bm_select" ON bank_movements;
CREATE POLICY "bm_select" ON bank_movements FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "bm_insert" ON bank_movements;
CREATE POLICY "bm_insert" ON bank_movements FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "bm_update" ON bank_movements;
CREATE POLICY "bm_update" ON bank_movements FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "bm_delete" ON bank_movements;
CREATE POLICY "bm_delete" ON bank_movements FOR DELETE TO anon, authenticated USING (true);