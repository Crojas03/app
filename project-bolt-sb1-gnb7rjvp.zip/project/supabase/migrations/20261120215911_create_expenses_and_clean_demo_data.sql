/*
# Módulo de Gastos y limpieza de datos de prueba

1. Nuevas tablas
- `expense_categories`: categorías de egreso (nombre, tipo: 'operativo' o
  'liquidaciones' para vueltos/propinas, orden).
- `expense_subcategories`: subcategorías dependientes de una categoría
  (nombre único por categoría, orden).
- `expenses`: gastos/salidas con fecha, tasa BCV, tipo de egreso
  (Gasto Operativo vs. Vueltos/Propinas), categoría, subcategoría,
  proveedor/beneficiario, método de pago, monto en la moneda del método y
  equivalentes calculados en USD y Bs, observación.

2. Limpieza de datos de prueba
- Se eliminan TODAS las filas de `sales`, `cash_backs` y `tips` (eran datos
  ficticios de demostración). El catálogo de `payment_methods` se conserva.

3. Seguridad
- RLS habilitado en las 3 tablas nuevas.
- Políticas TO anon, authenticated USING(true) (app de un solo usuario sin
  inicio de sesión, igual que el resto de las tablas).
- GRANT de CRUD a anon + authenticated.

4. Notas
- category_id y subcategory_id usan ON DELETE RESTRICT: la app impide borrar
  categorías/subcategorías en uso para no perder referencias.
*/

DELETE FROM tips;
DELETE FROM cash_backs;
DELETE FROM sales;

CREATE TABLE IF NOT EXISTS expense_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  kind text NOT NULL DEFAULT 'operativo' CHECK (kind IN ('operativo', 'liquidaciones')),
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expense_subcategories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES expense_categories(id) ON DELETE RESTRICT,
  name text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (category_id, name)
);

CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  expense_date date NOT NULL,
  bcv_rate numeric(14,4) NOT NULL CHECK (bcv_rate > 0),
  egress_type text NOT NULL CHECK (egress_type IN ('operativo', 'vueltos_propinas')),
  category_id uuid REFERENCES expense_categories(id) ON DELETE RESTRICT,
  subcategory_id uuid REFERENCES expense_subcategories(id) ON DELETE RESTRICT,
  provider text NOT NULL DEFAULT '',
  method_id uuid NOT NULL REFERENCES payment_methods(id) ON DELETE RESTRICT,
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  method_currency text NOT NULL CHECK (method_currency IN ('VES', 'USD')),
  amount_usd numeric(14,2) NOT NULL,
  amount_ves numeric(14,2) NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses (expense_date);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses (category_id);
CREATE INDEX IF NOT EXISTS idx_expenses_method ON expenses (method_id);
CREATE INDEX IF NOT EXISTS idx_subcats_category ON expense_subcategories (category_id);

ALTER TABLE expense_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_subcategories ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON expense_categories TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON expense_subcategories TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON expenses TO anon, authenticated;

DROP POLICY IF EXISTS "ec_select" ON expense_categories;
CREATE POLICY "ec_select" ON expense_categories FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ec_insert" ON expense_categories;
CREATE POLICY "ec_insert" ON expense_categories FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ec_update" ON expense_categories;
CREATE POLICY "ec_update" ON expense_categories FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ec_delete" ON expense_categories;
CREATE POLICY "ec_delete" ON expense_categories FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "es_select" ON expense_subcategories;
CREATE POLICY "es_select" ON expense_subcategories FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "es_insert" ON expense_subcategories;
CREATE POLICY "es_insert" ON expense_subcategories FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "es_update" ON expense_subcategories;
CREATE POLICY "es_update" ON expense_subcategories FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "es_delete" ON expense_subcategories;
CREATE POLICY "es_delete" ON expense_subcategories FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "ex_select" ON expenses;
CREATE POLICY "ex_select" ON expenses FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "ex_insert" ON expenses;
CREATE POLICY "ex_insert" ON expenses FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "ex_update" ON expenses;
CREATE POLICY "ex_update" ON expenses FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "ex_delete" ON expenses;
CREATE POLICY "ex_delete" ON expenses FOR DELETE TO anon, authenticated USING (true);

INSERT INTO expense_categories (name, kind, sort_order) VALUES
  ('Insumos/Mercancía', 'operativo', 1),
  ('Nómina', 'operativo', 2),
  ('Servicios', 'operativo', 3),
  ('Liquidaciones', 'liquidaciones', 4)
ON CONFLICT (name) DO NOTHING;

INSERT INTO expense_subcategories (category_id, name, sort_order)
SELECT c.id, s.name, s.ord
FROM expense_categories c
JOIN (VALUES
  ('Insumos/Mercancía', 'Carnes', 1),
  ('Insumos/Mercancía', 'Verduras', 2),
  ('Insumos/Mercancía', 'Víveres', 3),
  ('Insumos/Mercancía', 'Empaques', 4),
  ('Nómina', 'Sueldos', 1),
  ('Nómina', 'Bonos', 2),
  ('Servicios', 'Electricidad', 1),
  ('Servicios', 'Internet', 2),
  ('Servicios', 'Gas', 3),
  ('Liquidaciones', 'Vueltos por PM', 1),
  ('Liquidaciones', 'Pago de Propinas', 2)
) AS s(cat, name, ord) ON s.cat = c.name
ON CONFLICT (category_id, name) DO NOTHING;