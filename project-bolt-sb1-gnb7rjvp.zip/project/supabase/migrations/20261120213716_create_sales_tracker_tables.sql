/*
# Registro de ventas, vueltos, propinas y métodos de pago (single-tenant, sin auth)

1. Nuevas tablas
- `payment_methods`: métodos de pago con nombre, moneda (VES/USD), activo y
  columnas de plantilla de conciliación (JSONB).
- `sales`: ventas por turno (fecha, turno, tasa BCV, método, monto original,
  moneda del método, equivalente en USD y en Bs).
- `cash_backs` (vueltos): fecha, turno, concepto, monto, moneda y vía de
  entrega (pago móvil con banco/cuenta, o efectivo Bs).
- `tips` (propinas): fecha, turno, beneficiario, monto, moneda y vía/cuenta
  de entrada.

2. Seguridad
- RLS habilitado en las 4 tablas.
- Políticas TO anon, authenticated con USING(true)/WITH CHECK(true) porque es
  una app de un solo usuario sin inicio de sesión (datos intencionalmente
  compartidos).
- GRANT de SELECT/INSERT/UPDATE/DELETE a anon + authenticated.

3. Notas
- Sin user_id: app single-tenant sin autenticación.
- Guardo 4 políticas por tabla (SELECT/INSERT/UPDATE/DELETE).
*/

CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  currency text NOT NULL DEFAULT 'VES' CHECK (currency IN ('VES', 'USD')),
  active boolean NOT NULL DEFAULT true,
  reconciliation_columns jsonb NOT NULL DEFAULT '["Fecha","Referencia","Descripción","Monto"]'::jsonb,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_date date NOT NULL,
  shift text NOT NULL CHECK (shift IN ('diurno', 'nocturno')),
  bcv_rate numeric(14,4) NOT NULL CHECK (bcv_rate > 0),
  method_id uuid NOT NULL REFERENCES payment_methods(id) ON DELETE RESTRICT,
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  method_currency text NOT NULL CHECK (method_currency IN ('VES', 'USD')),
  amount_usd numeric(14,2) NOT NULL,
  amount_ves numeric(14,2) NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cash_backs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date date NOT NULL,
  shift text NOT NULL CHECK (shift IN ('diurno', 'nocturno')),
  concept text NOT NULL DEFAULT 'Vuelto',
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  currency text NOT NULL CHECK (currency IN ('VES', 'USD')),
  delivery_method text NOT NULL CHECK (delivery_method IN ('pago_movil', 'efectivo_bs')),
  bank_account text,
  bcv_rate numeric(14,4),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date date NOT NULL,
  shift text NOT NULL CHECK (shift IN ('diurno', 'nocturno')),
  person text NOT NULL DEFAULT 'Personal',
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  currency text NOT NULL CHECK (currency IN ('VES', 'USD')),
  via text NOT NULL,
  bank_account text,
  bcv_rate numeric(14,4),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sales_date ON sales (sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_shift ON sales (shift);
CREATE INDEX IF NOT EXISTS idx_cash_backs_date ON cash_backs (entry_date);
CREATE INDEX IF NOT EXISTS idx_tips_date ON tips (entry_date);

ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE cash_backs ENABLE ROW LEVEL SECURITY;
ALTER TABLE tips ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON payment_methods TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON sales TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON cash_backs TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON tips TO anon, authenticated;

DROP POLICY IF EXISTS "pm_select" ON payment_methods;
CREATE POLICY "pm_select" ON payment_methods FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "pm_insert" ON payment_methods;
CREATE POLICY "pm_insert" ON payment_methods FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "pm_update" ON payment_methods;
CREATE POLICY "pm_update" ON payment_methods FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "pm_delete" ON payment_methods;
CREATE POLICY "pm_delete" ON payment_methods FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "sales_select" ON sales;
CREATE POLICY "sales_select" ON sales FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "sales_insert" ON sales;
CREATE POLICY "sales_insert" ON sales FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "sales_update" ON sales;
CREATE POLICY "sales_update" ON sales FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "sales_delete" ON sales;
CREATE POLICY "sales_delete" ON sales FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "cb_select" ON cash_backs;
CREATE POLICY "cb_select" ON cash_backs FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "cb_insert" ON cash_backs;
CREATE POLICY "cb_insert" ON cash_backs FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "cb_update" ON cash_backs;
CREATE POLICY "cb_update" ON cash_backs FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "cb_delete" ON cash_backs;
CREATE POLICY "cb_delete" ON cash_backs FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "tips_select" ON tips;
CREATE POLICY "tips_select" ON tips FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "tips_insert" ON tips;
CREATE POLICY "tips_insert" ON tips FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "tips_update" ON tips;
CREATE POLICY "tips_update" ON tips FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "tips_delete" ON tips;
CREATE POLICY "tips_delete" ON tips FOR DELETE TO anon, authenticated USING (true);